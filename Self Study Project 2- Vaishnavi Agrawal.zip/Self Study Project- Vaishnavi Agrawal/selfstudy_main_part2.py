"""
Self Study DA2 — Part II: Instrumental Variables
Data Analytics II, University of St. Gallen
Vaishnavi Agrawal

"""

import os
os.chdir(r'C:\Users\Vaishnavi\OneDrive\Desktop\Python Projects\Self Study Project- Vaishnavi Agrawal')
import importlib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
from pathlib import Path
from scipy import stats
import selfstudy_functions as f
importlib.reload(f)

PATH     = Path(os.getcwd())
DATANAME = 'data_2.csv'

# ============================================================
# DATA PREPARATION
# ============================================================
data_raw      = pd.read_csv(PATH / DATANAME)
data_raw      = data_raw.dropna()
data_clean    = f.clean_data(data_raw)
region_labels = data_clean['region'].copy()

# ============================================================
# PART II: REGION A ONLY
# ============================================================
data_A       = data_clean[region_labels == 'A'].copy().reset_index(drop=True)
data_model_A = f.make_dummies(data_A)

print(f"\nRegion A observations: {len(data_A)}")
print(f"Offer rate  : {data_A['offer'].mean():.3f}")
print(f"Take-up rate: {data_A['takeup'].mean():.3f}")

# ============================================================
# DEFINING VARIABLE SETS
# ============================================================
INSTRUMENT = 'offer'
TREATMENT  = 'takeup'
OUTCOME    = 'outcome'

# Base covariates: all pre-treatment variables except instrument, treatment, outcome
COVARIATES = [
    col for col in data_model_A.columns
    if col not in [INSTRUMENT, TREATMENT, OUTCOME]
]

# For CIA estimators in Region A: include 'offer' so the propensity score
# and outcome models condition on the main driver of treatment assignment.
# This makes selection-on-observables more plausible.
COVARIATES_CIA = COVARIATES + [INSTRUMENT]

print(f"\nCovariates ({len(COVARIATES)}): {COVARIATES}\n")

# ============================================================
# SECTION 6: INSTRUMENT VALIDATION
# ============================================================
print('\n' + '=' * 80)
print('SECTION 6: INSTRUMENT VALIDATION')
print('=' * 80)

#Group sizes: offered vs not offered in Region A

f.plot_group_sizes(
    data_model=data_model_A,
    instrument=INSTRUMENT,
    path=PATH
)

#Balance check: offered vs not-offered units in Region A
balance_vars = [
    'age', 'baseline_income', 'unemp_duration', 'language_score',
    'gender', 'immigrant', 'disability', 'employment_gaps', 'special_trainings'
]
rand_check = f.iv_randomisation_check(
    data=data_A, instrument=INSTRUMENT,
    covariates=balance_vars, path=PATH
)




#Compliance types and shares

compliance = f.compute_compliance_types(
    data_model=data_model_A,
    instrument=INSTRUMENT,
    treatment=TREATMENT
)

# Compliance type plots (pie + 2x2 cells + offered group sizes) ---

f.plot_compliance_types(
    compliance=compliance,
    instrument=INSTRUMENT,
    treatment=TREATMENT,
    path=PATH
)

# First-stage regression (with covariates for F-stat)
first_stage = f.iv_first_stage(
    data_model=data_model_A, instrument=INSTRUMENT,
    treatment=TREATMENT, covariates=COVARIATES, path=PATH
)

#  First-stage bar chart with delta annotation 
f.plot_first_stage_annotated(
    data_model=data_model_A,
    instrument=INSTRUMENT,
    treatment=TREATMENT,
    path=PATH
)

# Balance check: takers vs non-takers (within offered group)
data_offered = data_A[data_A[INSTRUMENT] == 1].copy().reset_index(drop=True)
taker_check = f.balance_check(
    data=data_offered,
    treatment=TREATMENT,
    variables=balance_vars
)


# ============================================================
# SECTION 7: NAIVE OLS ESTIMATOR RESULTS (BIASED IN REGION A)
# ============================================================
print('\n' + '=' * 80)
print('SECTION 7: NAIVE OLS — biased, for illustration only')
print('=' * 80)

X_ols_naive = data_model_A[[TREATMENT]]   # takeup
ols_naive   = f.my_ols(exog=X_ols_naive, outcome=data_model_A[OUTCOME],
                       intercept=True, display=True)

# ============================================================
# SECTION 8: IV ESTIMATION — NO COVARIATES
# ============================================================
print('\n' + '=' * 80)
print('SECTION 8: IV ESTIMATION (no covariates)')
print('=' * 80)

#ITT: reduced form — outcome ~ offer, no covariates
itt = f.itt_estimate(
    data_model=data_model_A, instrument=INSTRUMENT,
    outcome=OUTCOME,
    covariates=[],
    path=PATH
) 

# LATE via Wald estimator w/o covariates
late = f.late_wald(
    data_model=data_model_A, instrument=INSTRUMENT,
    treatment=TREATMENT, outcome=OUTCOME, path=PATH
)

# 2SLS w/o covariates
tsls = f.tsls_estimate(
    data_model=data_model_A, instrument=INSTRUMENT,
    treatment=TREATMENT, outcome=OUTCOME,
    covariates=[],
    path=PATH
)

# ============================================================
# SECTION 9: COMPARISON OF IDENTIFICATION STRATEGIES
# CIA-based estimators with takeup as treatment and offer as covariate.
# ============================================================
print('\n' + '=' * 80)
print('SECTION 9: COMPARISON OF IDENTIFICATION STRATEGIES')
print('=' * 80)

X_cia = data_model_A[COVARIATES_CIA]   # covariates including offer

# Raw mean difference (no covariates, takeup as treatment)
md_result = f.ate_md(
    outcome=data_model_A[OUTCOME],
    treatment=data_model_A[TREATMENT]   # takeup, not offer
)
md_ate = md_result.loc['MeanDiff', 'ATE']
md_se  = md_result.loc['MeanDiff', 'SE']

# Regression Adjustment (takeup + COVARIATES_CIA)
ra_res = f.my_ols(
    exog=pd.concat([data_model_A[[TREATMENT]], X_cia], axis=1),
    outcome=data_model_A[OUTCOME],
    display=True
)
ra_ate = ra_res.loc[TREATMENT, 'coef']
ra_se  = ra_res.loc[TREATMENT, 'se']

# IPW (propensity score of takeup ~ COVARIATES_CIA, includes offer) 
ipw_res = f.my_ipw(
    exog=X_cia,
    outcome=data_model_A[OUTCOME],
    treat=data_model_A[TREATMENT],      # takeup, not offer
    boot=200, display=True
)
ipw_ate = ipw_res.loc[TREATMENT, 'coef']
ipw_se  = ipw_res.loc[TREATMENT, 'se']

# Doubly Robust (my_dr from selfstudy_functions.py) 
# df passed includes COVARIATES_CIA so offer enters both PS and outcome models
dr_df  = data_model_A[COVARIATES_CIA + [TREATMENT, OUTCOME]].copy()
dr_res = f.my_dr(
    df=dr_df,
    y_col=OUTCOME,
    treat_col=TREATMENT,
    boot=200, display=True
)
dr_ate = dr_res.loc[TREATMENT, 'coef']
dr_se  = dr_res.loc[TREATMENT, 'se']

# Comparison table + plot 
part1_results = {
    'Raw Mean Diff' : (md_ate, md_se),
    'Reg. Adjustment': (ra_ate, ra_se),
    'IPW'            : (ipw_ate, ipw_se),
    'Doubly Robust'  : (dr_ate, dr_se),
}

comp_table = f.iv_comparison_table(
    part1_results=part1_results,
    itt=itt,
    late_wald=late,
    tsls=tsls,
    path=PATH
)

f.plot_iv_comparison(comparison_table=comp_table, path=PATH)

print('\nPart II complete. All outputs saved to:', PATH)
