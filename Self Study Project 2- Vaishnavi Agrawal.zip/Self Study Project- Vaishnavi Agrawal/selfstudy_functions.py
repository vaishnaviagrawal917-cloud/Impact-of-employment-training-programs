"""
Self Study Functions File
Data Analytics II
University of St. Gallen
Vaishnavi Agrawal
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import statsmodels.api as sm
from scipy import stats
from sklearn import linear_model


# ==============================================================================
# DATA CLEANING AND PREPARATION
# ==============================================================================

def clean_data(data):
    """
    Cleans raw data by standardising region and education labels,
    converting age to numeric, and removing outliers.
    Parameters
    ----------
    data : pd.DataFrame
    Returns
    -------
    pd.DataFrame — cleaned dataframe
    """
    # work on a copy so we never accidentally modify the original dataframe
    data = data.copy()

    # the region column has inconsistent formatting across the raw data
    # (e.g. 'Region A', 'a', 'A ' all mean the same thing) so we map
    # everything to a clean single-letter label
    region_map = {
        'A': 'A', 'Region A': 'A', 'a': 'A', 'A ': 'A',
        'B': 'B', 'Region B': 'B', 'B-': 'B', 'b': 'B',
        'C': 'C', 'Region C': 'C', 'C_': 'C', 'c': 'C'
    }
    data['region'] = data['region'].map(region_map)

    # same issue with education - numeric codes, abbreviations, and full
    # labels all show up, so we standardise them to four clean categories
    education_map = {
        '0': 'Low', 'low': 'Low', 'LOW': 'Low',
        '1': 'Medium', 'Medium': 'Medium', 'med': 'Medium',
        '2': 'High', 'High': 'High', 'H': 'High',
        '3': 'Tertiary', 'Tertiary': 'Tertiary', 'uni': 'Tertiary'
    }
    data['education'] = data['education'].map(education_map)

    # age is stored as a string in some rows, so we force it to numeric
    # and round to 1 decimal to avoid floating point noise
    data['age'] = pd.to_numeric(data['age'], errors='coerce').round(1)

    # these variables were recorded after treatment was assigned, so they
    # cannot be used as covariates - including them would cause post-treatment bias
    post_treatment_vars = [
        'active_participation',
        'course_hours_completed', 'diploma_awarded', 'id'
    ]
    data = data.drop(columns=post_treatment_vars)

    # 999 is a common sentinel value used to flag missing entries in this dataset
    # we convert them to NaN so they get handled properly downstream
    for col in ['age', 'unemp_duration', 'baseline_income']:
        data[col] = data[col].replace(999.0, float('nan'))
        # 99 was used as the missing code for takeup specifically
        data['takeup'] = data['takeup'].replace(99, float('nan'))

    # drop rows with values that are clearly impossible given the context
    # anyone outside 18-80 is implausible for a labour market programme
    data = data[(data['age'] >= 18) & (data['age'] <= 80)]
    # negative unemployment duration makes no sense
    data = data[data['unemp_duration'] >= 0]
    # income above 150k is likely a data entry error in this context
    data = data[data['baseline_income'] <= 150000]

    # drop any remaining rows that still have missing values in any column
    data = data.dropna()

    return data


def make_dummies(data):
    """
    Creates dummy variables for region and education.
    Saves region labels before conversion for EDA use.
    Parameters
    ----------
    data : pd.DataFrame
    Returns
    -------
    pd.DataFrame - dataframe with dummies
    """
    # one-hot encode region and education, dropping the first category
    # to avoid the dummy variable trap (perfect multicollinearity)
    data = pd.get_dummies(data, columns=['region'], drop_first=True)
    data = pd.get_dummies(data, columns=['education'], drop_first=True)

    # get_dummies returns bool columns by default in newer pandas versions,
    # so we cast everything to int so matrix operations work cleanly later
    data = data.astype({
        col: int for col in data.select_dtypes(include='bool').columns
    })
    return data


# ==============================================================================
# DESCRIPTIVE STATISTICS
# ==============================================================================

def descriptive_stats(data, continuous, path):
    """
    Computes descriptive statistics of continuous variables by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    continuous : list of strings - continuous variable names
    path : string - path to save output
    Returns
    -------
    pd.DataFrame - descriptive statistics table
    """
    rows = []
    # loop over each region and each variable to build up a long-format table
    for region in ['A', 'B', 'C']:
        subset = data[data['region'] == region]
        for col in continuous:
            rows.append({
                'Region': region,
                'Variable': col,
                'Count': subset[col].count(),
                'Mean': subset[col].mean().round(2),
                'Std': subset[col].std().round(2),
                'Min': subset[col].min().round(2),
                'Median': subset[col].median().round(2),
                'Max': subset[col].max().round(2)
            })

    # pivot the list of dicts into a dataframe indexed by region and variable
    desc_stats = pd.DataFrame(rows).set_index(['Region', 'Variable'])
    print("=== Descriptive Statistics of Continuous Variables by Region ===")
    print(desc_stats.to_string())
    desc_stats.to_csv(str(Path(path) / 'descriptive_stats_by_region.csv'))

    return desc_stats


def binary_stats(data, binary, path):
    """
    Computes proportions of binary variables by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    binary : list of strings - binary variable names
    path : string - path to save output
    Returns
    -------
    pd.DataFrame - binary proportions table
    """
    # for binary variables, the mean is equivalent to the proportion
    stats = data.groupby('region')[binary].mean().round(3)
    # add sample size per region so it's easy to spot unbalanced groups
    stats['n_obs'] = data.groupby('region').size()
    print("\n=== Proportions of Binary Variables by Region ===")
    print(stats.to_string())
    stats.to_csv(str(Path(path) / 'binary_stats_by_region.csv'))

    return stats


def treatment_stats(data, path):
    """
    Computes offer and takeup rates by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    path : string - path to save output
    Returns
    -------
    pd.DataFrame - treatment statistics table
    """
    # offer and takeup rates tell us about the assignment and compliance
    # structure in each region - useful for understanding identification
    stats = data.groupby('region')[['offer', 'takeup']].mean().round(3)
    stats['n_obs'] = data.groupby('region').size()
    print("\n=== Treatment Offer and Takeup Rates by Region ===")
    print(stats.to_string())
    stats.to_csv(str(Path(path) / 'treatment_stats_by_region.csv'))

    return stats


# ==============================================================================
# VISUALISATIONS - PART I
# ==============================================================================

def plot_continuous(data, continuous, path):
    """
    Plots boxplots of continuous variables by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    continuous : list of strings
    path : string
    """
    # one subplot per variable, all in a single row for easy comparison
    fig, axes = plt.subplots(1, len(continuous), figsize=(15, 5))
    for ax, col in zip(axes, continuous):
        sns.boxplot(data=data, x='region', y=col, ax=ax, palette='Set2')
        ax.set_title(f'{col} by Region')
        ax.set_xlabel('Region')
        ax.set_ylabel(col)
    plt.suptitle('Continuous Variable Distributions by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'boxplots_continuous.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_binary(data, binary, path):
    """
    Plots bar charts of binary variable proportions by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    binary : list of strings
    path : string
    """
    fig, axes = plt.subplots(1, len(binary), figsize=(18, 5))
    for ax, col in zip(axes, binary):
        # groupby gives us mean per region, which is the proportion for binary vars
        data.groupby('region')[col].mean().plot(
            kind='bar', ax=ax, color='steelblue', edgecolor='black')
        ax.set_title(col)
        ax.set_xlabel('Region')
        ax.set_ylabel('Proportion')
        ax.set_xticklabels(['A', 'B', 'C'], rotation=0)
    plt.suptitle('Binary Variable Proportions by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'binary_proportions.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_outcome(data, path):
    """
    Plots outcome distribution by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    path : string
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, region in zip(axes, ['A', 'B', 'C']):
        subset = data[data['region'] == region]['outcome']
        ax.hist(subset, bins=30, color='steelblue', edgecolor='black')
        # add a vertical line at the mean so we can compare levels across regions
        ax.axvline(subset.mean(), color='red', linestyle='--',
                   label=f'Mean: {subset.mean():.0f}')
        ax.set_title(f'Outcome - Region {region}')
        ax.set_xlabel('Outcome')
        ax.set_ylabel('Frequency')
        ax.legend()
    plt.suptitle('Outcome Distribution by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'outcome_distribution.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_treatment(data, path):
    """
    Plots offer and takeup rates by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    path : string
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    # side-by-side bars make it easy to see the gap between offer and takeup rates,
    # which tells us about compliance in each region
    treatment_plot = data.groupby('region')[['offer', 'takeup']].mean()
    treatment_plot.plot(kind='bar', ax=ax,
                        color=['steelblue', 'coral'], edgecolor='black')
    ax.set_title('Treatment Offer and Takeup Rates by Region')
    ax.set_xlabel('Region')
    ax.set_ylabel('Proportion')
    ax.set_xticklabels(['A', 'B', 'C'], rotation=0)
    ax.legend(['Offer Rate', 'Takeup Rate'])
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'treatment_rates.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_education(data, path):
    """
    Plots education distribution by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    path : string
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    # unstack puts education categories as columns, giving us a grouped bar chart
    edu_counts = data.groupby(['region', 'education']).size().unstack(fill_value=0)
    edu_counts.plot(kind='bar', ax=ax, edgecolor='black')
    ax.set_title('Education Distribution by Region')
    ax.set_xlabel('Region')
    ax.set_ylabel('Count')
    ax.set_xticklabels(['A', 'B', 'C'], rotation=0)
    ax.legend(title='Education')
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'education_by_region.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_language_score(data, path):
    """
    Plots language score distribution by region.
    Parameters
    ----------
    data : pd.DataFrame - must contain original region labels
    path : string
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, region in zip(axes, ['A', 'B', 'C']):
        subset = data[data['region'] == region]['language_score']
        ax.hist(subset, bins=30, color='yellow', edgecolor='black')
        ax.axvline(subset.mean(), color='red', linestyle='--',
                   label=f'Mean: {subset.mean():.2f}')
        ax.set_title(f'Language Score - Region {region}')
        ax.set_xlabel('Language Score')
        ax.set_ylabel('Frequency')
        ax.legend()
    plt.suptitle('Language Score Distribution by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'language_score_distribution.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


# ==============================================================================
# COMMON SUPPORT / OVERLAP
# ==============================================================================

def common_support(exog, treat, path, bins=10, enforce=False, region=''):
    """
    Check and enforce common support.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    path : TYPE: string
        DESCRIPTION: path where the plot will be saved
    bins : TYPE: integer, optional
        DESCRIPTION: number of bins for the histogram.
        The default is 10.
    enforce : TYPE: boolean, optional
        DESCRIPTION: if common support should be enforced.
        The default is False.

    Returns
    -------
    result: Array of indices for overlap observations and plots/saves
    a common support histogram.
    """
    # fit a logistic regression of treatment on covariates to get propensity scores
    # disp=0 suppresses the convergence output to keep the console clean
    pscores = pd.Series(sm.Logit(
        endog=treat, exog=sm.add_constant(exog)).fit(disp=0).predict(),
        index=exog.index)

    # split propensity scores by treatment status so we can plot them separately
    pscores_d0 = pscores[treat == 0]
    pscores_d1 = pscores[treat == 1]

    # overlapping histograms let us visually assess whether treated and control
    # units have similar propensity score distributions
    plt.hist(pscores_d0, bins=bins, color='green', alpha=0.5, label='control')
    plt.hist(pscores_d1, bins=bins, color='black', alpha=0.5, label='treated')
    plt.legend(loc='best')
    plt.title(f'Histogram of Propensity Scores for Treated and Controls - Region {region}')
    plt.xlabel('Propensity Score')
    plt.ylabel('Counts')
    plt.grid(axis='y', alpha=0.75)
    plt.savefig(path / f'histogram_of_pscores_region_{region}.png')
    plt.show()

    if enforce:
        # if we want to enforce common support, we need to drop observations
        # that fall outside the overlap region between treated and control
        indices_d0 = exog.index[treat == 0]
        indices_d1 = exog.index[treat == 1]

        # the overlap region is bounded by the max of the minimums and the
        # min of the maximums - anything outside that is extrapolation
        min_pscores_d0 = np.amin(pscores[indices_d0])
        max_pscores_d0 = np.amax(pscores[indices_d0])
        min_pscores_d1 = np.amin(pscores[indices_d1])
        max_pscores_d1 = np.amax(pscores[indices_d1])

        # keep only units whose propensity score falls within the support of
        # both the treated and control distributions
        d0_cs = ((pscores[indices_d0] >= min_pscores_d1) &
                 (pscores[indices_d0] <= max_pscores_d1))
        d1_cs = ((pscores[indices_d1] >= min_pscores_d0) &
                 (pscores[indices_d1] <= max_pscores_d0))
        indices_d0_cs = indices_d0[d0_cs]
        indices_d1_cs = indices_d1[d1_cs]

        # merge the surviving treated and control indices and sort them
        overlap = np.sort(np.concatenate((indices_d0_cs, indices_d1_cs), axis=0))
    else:
        # if we are just checking (not enforcing), return all indices unchanged
        overlap = exog.index

    print('Number of observations off support: ',
          f'{len(exog) - len(overlap)}', '\n\n')
    return overlap


def overlap_numerical(exog, treat, region):
    """
    Numerically checks overlap by computing propensity score
    statistics for treated and control groups.
    Parameters
    ----------
    exog : pd.DataFrame - covariate matrix
    treat : pd.Series - treatment variable
    region : string - region label for printing
    """
    # estimate propensity scores the same way as common_support()
    pscores = pd.Series(
        sm.Logit(endog=treat, exog=sm.add_constant(exog)).fit(disp=0).predict(),
        index=exog.index
    )

    treated_ps = pscores[treat == 1]
    control_ps = pscores[treat == 0]

    # the common support region is where both score distributions overlap
    # anything below the higher minimum or above the lower maximum is outside
    lower = max(treated_ps.min(), control_ps.min())
    upper = min(treated_ps.max(), control_ps.max())

    # count how many observations actually fall inside the overlap window
    inside  = ((pscores >= lower) & (pscores <= upper)).sum()
    outside = len(pscores) - inside

    # build a clean summary table of PS statistics for each group
    results = pd.DataFrame({
        'Group': ['Treated', 'Control'],
        'N': [len(treated_ps), len(control_ps)],
        'Mean PS': [treated_ps.mean().round(3), control_ps.mean().round(3)],
        'Std PS':  [treated_ps.std().round(3),  control_ps.std().round(3)],
        'Min PS':  [treated_ps.min().round(3),  control_ps.min().round(3)],
        'Max PS':  [treated_ps.max().round(3),  control_ps.max().round(3)]
    })

    print(f"\n=== Numerical Overlap Check - Region {region} ===")
    print(results.to_string(index=False))
    print(f"\nCommon support: [{lower:.3f}, {upper:.3f}]")
    print(f"Inside support:  {inside}  ({100*inside/len(pscores):.1f}%)")
    print(f"Outside support: {outside} ({100*outside/len(pscores):.1f}%)")


# ==============================================================================
# TREATMENT EFFECT ESTIMATORS
# ==============================================================================

def ate_md(outcome, treatment):
    """
    Estimate ATE by differences in means.

    Parameters
    ----------
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treatment : TYPE: pd.Series
        DESCRIPTION: vector of treatments

    Returns
    -------
    results : ATE with Standard Error
    """
    # split the outcome vector by treatment status
    y_1 = outcome.loc[treatment == 1]
    y_0 = outcome.loc[treatment == 0]

    # the ATE is simply the difference in group means
    ate = y_1.mean() - y_0.mean()

    # SE for the difference in means using the Welch formula
    # (does not assume equal variances across groups)
    ate_se = np.sqrt(y_1.var() / len(y_1) + y_0.var() / len(y_0))

    ate_tval = ate / ate_se

    # two-sided p-value from the standard normal - sf(x) = 1 - cdf(x)
    ate_pval = stats.norm.sf(abs(ate_tval)) * 2

    result = pd.DataFrame([ate, ate_se, ate_tval, ate_pval],
                          index=['ATE', 'SE', 't-value', 'p-value'],
                          columns=['MeanDiff']).transpose()

    print('ATE Estimate by Difference in Means:', '-' * 80,
          'Dependent Variable: ' + outcome.name, '-' * 80,
          round(result, 2), '-' * 80, '\n\n', sep='\n')
    return result


def my_ols(exog, outcome, intercept=True, display=True):
    """
    OLS estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: outcome
    intercept : TYPE: boolean
        DESCRIPTION: should intercept be included? The default is True.
    display : TYPE: boolean
        DESCRIPTION: should results be displayed? The default is True.

    Returns
    -------
    result: ols estimates with standard errors
    """
    if intercept:
        # prepend a column of ones to add an intercept to the model
        exog = pd.concat([pd.Series(np.ones(len(exog)), index=exog.index,
                                    name='intercept'), exog], axis=1)

    # compute the OLS estimator: beta = (X'X)^{-1} X'y
    x_inv = np.linalg.inv(np.dot(exog.T, exog))
    betas = np.dot(x_inv, np.dot(exog.T, outcome))

    # residuals = actual outcome minus fitted values
    res = outcome - np.dot(exog, betas)

    # standard errors: sqrt of the diagonal of sigma^2 * (X'X)^{-1}
    # we use (N - p) in the denominator to correct for degrees of freedom
    s_e = np.sqrt(np.diagonal(np.dot(np.dot(res.T, res), x_inv) /
                              (exog.shape[0] - exog.shape[1])))

    tval = betas / s_e

    # t-distribution p-values with N-p degrees of freedom (two-sided)
    pval = stats.t.sf(np.abs(tval), (exog.shape[0] - exog.shape[1])) * 2

    result = pd.DataFrame([betas, s_e, tval, pval],
                          index=['coef', 'se', 't-value', 'p-value'],
                          columns=list(exog.columns.values)).transpose()

    if display:
        print('OLS Estimation Results:', '-' * 80,
              'Dependent Variable: ' + outcome.name, '-' * 80,
              round(result, 2), '-' * 80, '\n\n', sep='\n')
    return result


def ipw_formula(treat, outcome, prob, normalize=True):
    """
    IPW formula.

    Parameters
    ----------
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    prob : TYPE: pd.Series / array
        DESCRIPTION: vector of probabilities

    Returns
    -------
    result: ATE estimate according to IPW
    """
    if not normalize:
        # standard (Horvitz-Thompson) IPW: weight each unit by 1/P(D=d|X)
        # known to be unstable when propensity scores are near 0 or 1
        ate = np.mean(treat * outcome / prob
                      - (1 - treat) * outcome / (1 - prob))
    else:
        # normalised (Hajek) IPW: dividing by the sum of weights makes each
        # group's weights sum to 1, improving stability in small samples
        w_1 = treat / prob
        w_0 = (1 - treat) / (1 - prob)
        w_1 = w_1 / np.sum(w_1)
        w_0 = w_0 / np.sum(w_0)
        ate = np.sum(w_1 * outcome) - np.sum(w_0 * outcome)
    return ate


def ate_ipw(exog, outcome, treat,
            intercept=True, lasso=False, cval=False, folds=10):
    """
    ATE estimation by IPW.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    intercept : TYPE: boolean, optional
        DESCRIPTION: if intercept should be used.
        The default is True.
    lasso : TYPE: boolean, optional
        DESCRIPTION: if lasso should be used for propensity score.
        The default is False.
    cval : TYPE: boolean, optional
        DESCRIPTION: if cross-validation should be used for lasso.
        The default is False.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cross-validation.
        The default is 10.

    Returns
    -------
    result: ATE estimate according to IPW with logit propensity scores
    """
    if lasso:
        # lasso can be useful when there are many covariates and we want to
        # shrink irrelevant ones toward zero for a better propensity score model
        if cval:
            # use cross-validation to pick the optimal regularisation strength
            pscores = my_cv_lasso(exog=exog, outcome=treat,
                                  intercept=intercept,
                                  folds=folds)['predictions']
        else:
            if intercept:
                pscores = sm.OLS(endog=treat,
                                 exog=sm.add_constant(exog)).fit_regularized(
                                     ).predict()
            else:
                pscores = sm.OLS(endog=treat,
                                 exog=exog).fit_regularized().predict()
    else:
        # default path: logistic regression propensity scores
        # logit gives probabilities bounded in (0,1) which is what we need
        if intercept:
            pscores = sm.Logit(endog=treat, exog=sm.add_constant(exog)).fit(
                disp=0).predict()
        else:
            pscores = sm.Logit(endog=treat, exog=exog).fit(disp=0).predict()

    # feed the estimated propensity scores into the IPW formula
    ate = ipw_formula(treat=treat, outcome=outcome, prob=pscores)
    return ate, pscores


def ate_ipw_boot(exog, outcome, treat, intercept=True,
                 reps=100, lasso=False, cval=False, folds=10):
    """
    Bootstrap Standard Errors for IPW Estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    intercept : TYPE: boolean, optional
        DESCRIPTION: if intercept should be used.
        The default is True.
    reps : TYPE: integer, optional
        DESCRIPTION: Number of bootstrap replications for inference.
        The default is 100.
    lasso : TYPE: boolean, optional
        DESCRIPTION: if lasso should be used for propensity score.
        The default is False.
    cv : TYPE: boolean, optional
        DESCRIPTION: if cross-validation should be used for lasso.
        The default is False.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cross-validation.
        The default is 10.

    Returns
    -------
    result: bootstrap standard error for ATE
    """
    # pre-allocate an array to store the ATE from each bootstrap replication
    ate_boot = np.empty(reps)

    # fix the random seed so results are reproducible across runs
    rng = np.random.default_rng(12345)

    for rep_id in range(reps):
        # draw a bootstrap sample: same size as original, with replacement
        # some observations appear multiple times, others not at all
        boot_sample = rng.choice(exog.index, size=exog.shape[0], replace=True)

        exog_boot    = exog.loc[boot_sample, :]
        outcome_boot = outcome.loc[boot_sample]
        treat_boot   = treat.loc[boot_sample]

        # re-estimate the IPW ATE on this bootstrap sample
        ate_boot[rep_id], _ = ate_ipw(
            exog=exog_boot, outcome=outcome_boot,
            treat=treat_boot, intercept=intercept,
            lasso=lasso, cval=cval, folds=folds)

    # the bootstrap SE is the standard deviation of the replicated estimates
    ate_se = np.std(ate_boot)
    return ate_se


def my_cv_lasso(exog, outcome, intercept=True, folds=5):
    """
    Cross-validation for lasso.

    Parameters
    ----------
    exog : TYPE: pd.Series
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    intercept : TYPE: boolean
        DESCRIPTION: should intercept be included? The default is True.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cv. The default is 10.

    Returns
    -------
    result: optimal alpha (lambda) and betas and predictions
    """
    # standardise covariates before lasso so the penalty is on the same scale
    # for all variables - if we skip this, variables with larger ranges get
    # penalised more heavily, which biases the coefficient estimates
    exog_mean   = exog.mean()
    exog_std    = exog.std().replace(0, 1)   # replace zeros to avoid division by zero
    exog_scaled = (exog - exog_mean) / exog_std

    # search over a grid of regularisation parameters
    alpha_grid = np.arange(0.001, 0.01, 0.001)
    alpha_mse  = np.empty_like(alpha_grid)

    # randomly assign each observation to one of the k folds
    fold_ids = np.random.randint(0, folds, size=exog.shape[0])

    for jdx, alpha in enumerate(alpha_grid):
        cv_mse = []
        for fold in np.unique(fold_ids):
            # train on all folds except the current one
            model = linear_model.Lasso(alpha=alpha, fit_intercept=intercept)
            model.fit(X=exog.loc[fold_ids != fold, :],
                      y=outcome.loc[fold_ids != fold])
            # predict on the held-out fold and measure MSE
            yhat = model.predict(X=exog.loc[fold_ids == fold, :])
            cv_mse.append(np.mean((outcome.loc[fold_ids == fold] - yhat) ** 2))
        # average MSE across folds for this alpha value
        alpha_mse[jdx] = np.mean(cv_mse)

    # pick the alpha with the lowest average cross-validated MSE
    alpha_opt = alpha_grid[np.argmin(alpha_mse)]

    # refit on the full dataset using the optimal regularisation strength
    model = linear_model.Lasso(alpha=alpha_opt, fit_intercept=intercept
                               ).fit(X=exog, y=outcome)
    yhat  = model.predict(X=exog)

    if intercept:
        betas = pd.Series([model.intercept_] + list(model.coef_),
                          index=['intercept'] + list(exog.columns.values))
    else:
        betas = pd.Series(list(model.coef_), index=list(exog.columns.values))

    result = {"alpha": alpha_opt, "betas": betas, "predictions": yhat}
    return result


def my_ipw(exog, outcome, treat, intercept=True, display=True,
           boot=100, lasso=False, cval=False, folds=10, balance=False):
    """
    IPW estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    intercept : TYPE: boolean, optional
        DESCRIPTION: if intercept should be used.
        The default is True.
    boot : TYPE: integer, optional
        DESCRIPTION: Number of bootstrap replications for inference.
        The default is 100.
    lasso : TYPE: boolean, optional
        DESCRIPTION: if lasso should be used for propensity score.
        The default is False.
    cval : TYPE: boolean, optional
        DESCRIPTION: if cross-validation should be used for lasso.
        The default is False.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cross-validation.
        The default is 10.

    Returns
    -------
    result: ipw estimates with standard errors
    """
    # get the point estimate and the propensity scores from ate_ipw
    ate, pscores = ate_ipw(
        exog=exog, outcome=outcome, treat=treat, intercept=intercept,
        lasso=lasso, cval=cval, folds=folds)

    # we cannot get an analytic SE for IPW easily, so we use the bootstrap
    ate_se = ate_ipw_boot(exog=exog, outcome=outcome, treat=treat,
                          intercept=intercept, reps=boot, lasso=lasso,
                          cval=cval, folds=folds)

    tval = ate / ate_se
    # t-distribution p-value with degrees of freedom = N - number of covariates
    pval = stats.t.sf(np.abs(tval), (exog.shape[0] - exog.shape[1])) * 2

    result = pd.DataFrame([ate, ate_se, tval, pval],
                          index=['coef', 'se', 't-value', 'p-value'],
                          columns=[treat.name]).transpose()

    if balance:
        # optionally compute weighted mean differences for each covariate
        # to check whether IPW achieves balance - useful for diagnostics
        def helper(x_dat):
            return ipw_formula(treat, x_dat, pscores)
        b_result = exog.apply(helper, axis=0)

    if display:
        print('IPW Estimation Results:', '-' * 80,
              'Dependent Variable: ' + outcome.name, '-' * 80,
              round(result, 2), '-' * 80, '\n\n', sep='\n')

    if balance:
        return result, b_result
    return result


def balance_check(data, treatment, variables):
    """
    Check covariate balance.

    Parameters
    ----------
    data : TYPE: pd.DataFrame
        DESCRIPTION: data on which balancing checks should be conducted
    treatment : TYPE: string
        DESCRIPTION: name of the binary treatment variable
    variables : TYPE: tuple
        DESCRIPTION: names of the variables for balancing checks

    Returns
    -------
    Returns and Prints the Table of Descriptive Balancing Checks
    """
    balance = {}
    for varname in variables:
        treated = data.loc[data[treatment] == 1, varname]
        control = data.loc[data[treatment] == 0, varname]

        # raw mean difference between treated and control
        mdiff = treated.mean() - control.mean()

        # standard error of the difference using the Welch formula
        mdiff_std = (np.sqrt(treated.var() / len(treated)
                     + control.var() / len(control)))

        mdiff_tval = mdiff / mdiff_std

        # two-sided p-value from the standard normal
        mdiff_pval = stats.norm.sf(abs(mdiff_tval)) * 2

        # standardised difference expresses the gap in units of pooled SD
        # values above 10% are typically considered meaningful imbalance
        sdiff = abs(mdiff / np.sqrt((treated.var() + control.var()) / 2)) * 100

        balance[varname] = [treated.mean(), control.mean(),
                            mdiff, mdiff_std, mdiff_tval, mdiff_pval, sdiff]

    balance = pd.DataFrame(balance,
                           index=["Treated", "Control", "MeanDiff", "Std",
                                  "tVal", "pVal", "StdDiff"]).transpose()
    print('Balancing Checks:', '-' * 80,
          round(balance, 2), '-' * 80, '\n\n', sep='\n')
    return balance


# ==============================================================================
# IV FUNCTIONS - PART II
# ==============================================================================

def iv_randomisation_check(data, instrument, covariates, path):
    """
    Checks whether the instrument (offer) is randomly assigned by running
    balance checks between offered and non-offered units.

    Parameters
    ----------
    data       : pd.DataFrame - Region A data with original column names
    instrument : string       - name of the instrument column (e.g. 'offer')
    covariates : list         - covariate names to check balance on
    path       : Path         - directory to save output

    Returns
    -------
    pd.DataFrame - balance table (same format as balance_check)
    """
    balance = {}
    for varname in covariates:
        offered     = data.loc[data[instrument] == 1, varname]
        not_offered = data.loc[data[instrument] == 0, varname]

        # if the offer is truly random, there should be no systematic difference
        # in baseline characteristics between offered and non-offered groups
        mdiff      = offered.mean() - not_offered.mean()
        mdiff_std  = np.sqrt(offered.var() / len(offered)
                             + not_offered.var() / len(not_offered))
        mdiff_tval = mdiff / mdiff_std
        mdiff_pval = stats.norm.sf(abs(mdiff_tval)) * 2
        sdiff      = abs(mdiff / np.sqrt(
                         (offered.var() + not_offered.var()) / 2)) * 100

        balance[varname] = [offered.mean(), not_offered.mean(),
                            mdiff, mdiff_std, mdiff_tval, mdiff_pval, sdiff]

    balance_df = pd.DataFrame(
        balance,
        index=["Offered", "Not Offered", "MeanDiff", "Std",
               "t-Val", "p-Val", "StdDiff"]
    ).transpose().round(3)

    print('Instrument Randomisation Check (Offer Balance):',
          '-' * 80, balance_df.to_string(), '-' * 80, '\n', sep='\n')
    balance_df.to_csv(str(path / 'iv_randomisation_check.csv'))
    return balance_df


def iv_first_stage(data_model, instrument, treatment, covariates, path):
    """
    Estimates the first-stage regression: takeup ~ offer + X.
    Reports the coefficient on offer, its SE, t-value, p-value,
    and the F-statistic for instrument strength.

    Parameters
    ----------
    data_model  : pd.DataFrame - dummified Region A data
    instrument  : string       - instrument column name ('offer')
    treatment   : string       - endogenous treatment column ('takeup')
    covariates  : list         - control variable names
    path        : Path         - directory to save output

    Returns
    -------
    dict with keys: 'ols_result' (full OLS table), 'f_stat' (float),
                    'f_pval' (float), 'pi_hat' (float, coefficient on Z)
    """
    # regress takeup on the instrument and all covariates
    X = data_model[covariates + [instrument]]
    Y = data_model[treatment]
    result = my_ols(exog=X, outcome=Y, intercept=True, display=False)

    # pull out the key numbers for the instrument row only
    pi_hat  = result.loc[instrument, 'coef']
    pi_se   = result.loc[instrument, 'se']
    pi_tval = result.loc[instrument, 't-value']
    pi_pval = result.loc[instrument, 'p-value']

    # for a single instrument, the F-statistic is just the t-statistic squared
    # the Stock-Yogo rule of thumb is F > 10 to rule out weak instruments
    f_stat = pi_tval ** 2
    f_pval = stats.f.sf(f_stat, 1, len(X) - X.shape[1] - 1)

    print('First-Stage Regression (Takeup ~ Offer + X):', '-' * 80,
          round(result, 4).to_string(), '-' * 80,
          f'Coefficient on instrument ({instrument}): {pi_hat:.4f}  '
          f'SE: {pi_se:.4f}  t: {pi_tval:.3f}  p: {pi_pval:.4f}',
          f'First-stage F-statistic: {f_stat:.2f}  (p = {f_pval:.4f})',
          '(Rule of thumb: F > 10 indicates strong instrument)',
          '-' * 80, '\n', sep='\n')

    result.to_csv(str(path / 'iv_first_stage.csv'))
    return {'ols_result': result, 'f_stat': f_stat,
            'f_pval': f_pval, 'pi_hat': pi_hat}


def itt_estimate(data_model, instrument, outcome, covariates, path):
    """
    Estimates the Intent-to-Treat (ITT) effect: outcome ~ offer + X.
    The ITT is the reduced-form effect of being offered training,
    regardless of whether the individual actually participated.

    Parameters
    ----------
    data_model : pd.DataFrame - dummified Region A data
    instrument : string       - instrument column ('offer')
    outcome    : string       - outcome column name
    covariates : list         - control variable names
    path       : Path         - directory to save output

    Returns
    -------
    dict with keys: 'ols_result', 'itt' (float), 'itt_se', 'itt_tval', 'itt_pval'
    """
    # the ITT is just a regression of outcome on the offer (instrument)
    # no treatment variable in here because we ignore actual participation
    cols = [instrument] + covariates if covariates else [instrument]
    X    = data_model[cols]
    Y    = data_model[outcome]

    result = my_ols(exog=X, outcome=Y, intercept=True, display=False)

    # the ITT estimate is the coefficient on the instrument in this regression
    itt      = result.loc[instrument, 'coef']
    itt_se   = result.loc[instrument, 'se']
    itt_tval = result.loc[instrument, 't-value']
    itt_pval = result.loc[instrument, 'p-value']

    label = 'Outcome ~ Offer' if not covariates else 'Outcome ~ Offer + X'
    print(f'ITT Estimate ({label}):', '-' * 80,
          round(result, 4).to_string(), '-' * 80,
          f'ITT (coefficient on {instrument}): {itt:.4f}  '
          f'SE: {itt_se:.4f}  t: {itt_tval:.3f}  p: {itt_pval:.4f}',
          '-' * 80, '\n', sep='\n')

    result.to_csv(str(path / 'iv_itt.csv'))
    return {'ols_result': result, 'itt': itt, 'itt_se': itt_se,
            'itt_tval': itt_tval, 'itt_pval': itt_pval}


def late_wald(data_model, instrument, treatment, outcome, path):
    """
    Estimates the Local Average Treatment Effect (LATE) via the Wald estimator:
        LATE = ITT / First-Stage
             = Cov(Y, Z) / Cov(D, Z)
             = (E[Y|Z=1] - E[Y|Z=0]) / (E[D|Z=1] - E[D|Z=0])

    Standard error is computed via the delta method.

    Parameters
    ----------
    data_model : pd.DataFrame - dummified Region A data
    instrument : string       - 'offer'
    treatment  : string       - 'takeup'
    outcome    : string       - outcome column
    path       : Path         - directory to save output

    Returns
    -------
    dict with keys: 'late', 'late_se', 'late_tval', 'late_pval'
    """
    Z = data_model[instrument]
    D = data_model[treatment]
    Y = data_model[outcome]

    # compute the group means needed for the Wald formula
    y1 = Y[Z == 1].mean();  y0 = Y[Z == 0].mean()
    d1 = D[Z == 1].mean();  d0 = D[Z == 0].mean()

    # ITT = difference in mean outcomes by offer status (reduced form)
    # first stage = difference in mean takeup by offer status
    itt_raw = y1 - y0
    fs_raw  = d1 - d0
    # LATE = ITT / first stage, scaling the offer effect up to a per-participation effect
    late    = itt_raw / fs_raw

    # the SE comes from the delta method, which approximates the variance of a ratio
    # Var(A/B) ~ (1/B)^2 * Var(A) + (A/B^2)^2 * Var(B)
    n1 = (Z == 1).sum();  n0 = (Z == 0).sum()
    var_y1 = Y[Z == 1].var() / n1;  var_y0 = Y[Z == 0].var() / n0
    var_d1 = D[Z == 1].var() / n1;  var_d0 = D[Z == 0].var() / n0

    var_itt = var_y1 + var_y0
    var_fs  = var_d1 + var_d0
    late_se = np.sqrt((1 / fs_raw) ** 2 * var_itt
                      + (itt_raw / fs_raw ** 2) ** 2 * var_fs)

    late_tval = late / late_se
    # use the normal distribution for inference here (large sample approximation)
    late_pval = stats.norm.sf(abs(late_tval)) * 2

    print('Wald Estimator - LATE:', '-' * 80,
          f'Reduced form  (ITT, no controls): {itt_raw:.4f}',
          f'First stage   (FS,  no controls): {fs_raw:.4f}',
          f'LATE = ITT / FS                 : {late:.4f}',
          f'SE (delta method)               : {late_se:.4f}',
          f't-value                         : {late_tval:.3f}',
          f'p-value                         : {late_pval:.4f}',
          '-' * 80, '\n', sep='\n')

    result = pd.DataFrame(
        {'LATE': late, 'SE': late_se, 't-value': late_tval, 'p-value': late_pval},
        index=['Wald']
    )
    result.to_csv(str(path / 'iv_late_wald.csv'))
    return {'late': late, 'late_se': late_se,
            'late_tval': late_tval, 'late_pval': late_pval}


def tsls_estimate(data_model, instrument, treatment, outcome, covariates, path):
    """
    2SLS estimation of the LATE controlling for covariates.

    Stage 1: Regress D on Z and X  -> get D_hat
    Stage 2: Regress Y on D_hat and X

    Standard errors are corrected for the generated regressor in stage 2
    using the sandwich (HC0) formula.

    Parameters
    ----------
    data_model : pd.DataFrame - dummified Region A data
    instrument : string       - 'offer'
    treatment  : string       - 'takeup'
    outcome    : string       - outcome column
    covariates : list         - control variable names
    path       : Path         - directory to save output

    Returns
    -------
    dict with keys: 'coef' (2SLS coefficient on D), 'se', 'tval', 'pval',
                    'stage1_result', 'stage2_result'
    """
    n = len(data_model)

    # Stage 1: regress takeup on offer + covariates to get the fitted values
    # D_hat is the part of takeup that is explained by the exogenous offer
    s1_cols = [instrument] + covariates if covariates else [instrument]
    X1      = sm.add_constant(data_model[s1_cols])
    stage1  = sm.OLS(data_model[treatment], X1).fit()
    D_hat   = pd.Series(stage1.fittedvalues, index=data_model.index, name='D_hat')

    # Stage 2: regress outcome on D_hat (not actual takeup) + covariates
    # using D_hat instead of D strips out the endogenous variation in takeup
    if covariates:
        X2 = sm.add_constant(pd.concat([data_model[covariates], D_hat], axis=1))
    else:
        X2 = sm.add_constant(D_hat.to_frame())
    stage2 = sm.OLS(data_model[outcome], X2).fit()

    # the SEs from stage 2 are wrong because they use D_hat residuals instead of
    # the residuals from the true structural equation - we correct for this by
    # recomputing sigma^2 using the original treatment variable
    if covariates:
        D_orig_in_X2 = X2.drop(columns='const').assign(
                           **{'D_hat': data_model[treatment].values}
                       ).values
        resid_correct = (data_model[outcome].values
                         - D_orig_in_X2 @ stage2.params[1:].values
                         - stage2.params['const'])
    else:
        resid_correct = (data_model[outcome].values
                         - data_model[treatment].values * stage2.params['D_hat']
                         - stage2.params['const'])

    # build the corrected covariance matrix using the sandwich formula
    sigma2   = np.dot(resid_correct, resid_correct) / (n - X2.shape[1])
    X2_arr   = X2.values
    cov_2sls = sigma2 * np.linalg.inv(X2_arr.T @ X2_arr)
    se_2sls  = np.sqrt(np.diag(cov_2sls))

    coefs_2sls = stage2.params.values
    tvals_2sls = coefs_2sls / se_2sls
    pvals_2sls = stats.t.sf(np.abs(tvals_2sls), n - X2.shape[1]) * 2

    result_2sls = pd.DataFrame(
        {'coef': coefs_2sls, 'se': se_2sls,
         't-value': tvals_2sls, 'p-value': pvals_2sls},
        index=X2.columns
    ).round(4)

    # D_hat row gives us the 2SLS coefficient on the instrumented takeup variable
    tsls_coef = result_2sls.loc['D_hat', 'coef']
    tsls_se   = result_2sls.loc['D_hat', 'se']
    tsls_tval = result_2sls.loc['D_hat', 't-value']
    tsls_pval = result_2sls.loc['D_hat', 'p-value']

    print('2SLS Estimation Results:', '-' * 80,
          result_2sls.to_string(), '-' * 80,
          f'2SLS coefficient on {treatment}: {tsls_coef:.4f}  '
          f'SE: {tsls_se:.4f}  t: {tsls_tval:.3f}  p: {tsls_pval:.4f}',
          '-' * 80, '\n', sep='\n')

    result_2sls.to_csv(str(path / 'iv_2sls.csv'))
    return {'coef': tsls_coef, 'se': tsls_se,
            'tval': tsls_tval, 'pval': tsls_pval,
            'full_result': result_2sls}


def iv_comparison_table(part1_results, itt, late_wald, tsls, path):
    """
    Builds a summary comparison table of all estimators across Part I and II.

    Parameters
    ----------
    part1_results : dict  - {'RawMD': (ate, se), 'RA': (ate, se),
                              'IPW': (ate, se), 'DR': (ate, se)}
    itt           : dict  - from itt_estimate()
    late_wald     : dict  - from late_wald()
    tsls          : dict  - from tsls_estimate()
    path          : Path  - directory to save output

    Returns
    -------
    pd.DataFrame - comparison table
    """
    rows = []

    # add the CIA-based estimators from Part I (or the equivalent for Region A)
    for name, (ate, se) in part1_results.items():
        tval = ate / se
        pval = stats.norm.sf(abs(tval)) * 2
        rows.append({'Method': name, 'Estimand': 'ATE/ATET',
                     'Estimate': round(ate, 2), 'SE': round(se, 2),
                     't-value': round(tval, 2), 'p-value': round(pval, 4)})

    # add the three IV estimands
    rows.append({'Method': 'ITT', 'Estimand': 'ITT',
                 'Estimate': round(itt['itt'], 2),
                 'SE': round(itt['itt_se'], 2),
                 't-value': round(itt['itt_tval'], 2),
                 'p-value': round(itt['itt_pval'], 4)})

    rows.append({'Method': 'Wald LATE', 'Estimand': 'LATE',
                 'Estimate': round(late_wald['late'], 2),
                 'SE': round(late_wald['late_se'], 2),
                 't-value': round(late_wald['late_tval'], 2),
                 'p-value': round(late_wald['late_pval'], 4)})

    rows.append({'Method': '2SLS', 'Estimand': 'LATE',
                 'Estimate': round(tsls['coef'], 2),
                 'SE': round(tsls['se'], 2),
                 't-value': round(tsls['tval'], 2),
                 'p-value': round(tsls['pval'], 4)})

    table = pd.DataFrame(rows).set_index('Method')
    print('Comparison Table - All Estimators:', '-' * 80,
          table.to_string(), '-' * 80, '\n', sep='\n')
    table.to_csv(str(path / 'iv_comparison_table.csv'))
    return table


def plot_first_stage(data_model, instrument, treatment, path):
    """
    Scatter plot of takeup rate by offer status with fitted first-stage means.
    Visualises the first-stage relationship.

    Parameters
    ----------
    data_model : pd.DataFrame
    instrument : string
    treatment  : string
    path       : Path
    """
    # compute mean takeup separately for offered and non-offered groups
    means = data_model.groupby(instrument)[treatment].mean()

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.bar(means.index.astype(str), means.values,
           color=['steelblue', 'coral'], edgecolor='black', width=0.4)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(['Not Offered (Z=0)', 'Offered (Z=1)'])
    ax.set_ylabel('Mean Take-up Rate')
    ax.set_title('First Stage: Take-up by Offer Status')
    # annotate each bar with the exact take-up rate for easy reading
    for i, (xi, yi) in enumerate(zip([0, 1], means.values)):
        ax.text(xi, yi + 0.005, f'{yi:.3f}', ha='center', fontsize=11)
    plt.tight_layout()
    plt.savefig(str(path / 'iv_first_stage_plot.png'), dpi=150,
                bbox_inches='tight')
    plt.show()


def plot_iv_comparison(comparison_table, path):
    """
    Bar chart comparing all estimator point estimates with +/-1.96 SE bands.

    Parameters
    ----------
    comparison_table : pd.DataFrame - from iv_comparison_table()
    path             : Path
    """
    methods   = comparison_table.index.tolist()
    estimates = comparison_table['Estimate'].values
    ses       = comparison_table['SE'].values

    fig, ax = plt.subplots(figsize=(9, 5))
    # blue for CIA estimators, red for ITT, green for LATE estimators
    colors = ['steelblue'] * 4 + ['coral', 'seagreen', 'seagreen']
    ax.bar(methods, estimates, color=colors[:len(methods)],
           edgecolor='black', alpha=0.8)
    # add 95% confidence intervals as error bars - fmt='none' means no marker point
    ax.errorbar(methods, estimates, yerr=1.96 * ses,
                fmt='none', color='black', capsize=5, linewidth=1.5)
    ax.set_ylabel('Estimated Treatment Effect')
    ax.set_title('Comparison of Estimators - Region A')
    ax.axhline(0, color='black', linewidth=0.8, linestyle='--')
    plt.xticks(rotation=15, ha='right')
    plt.tight_layout()
    plt.savefig(str(path / 'iv_comparison_plot.png'), dpi=150,
                bbox_inches='tight')
    plt.show()


# ==============================================================================
# PART II VISUALISATIONS
# ==============================================================================

def compute_compliance_types(data_model, instrument, treatment):
    """
    Computes compliance type shares from a 2x2 (Z, D) cell count table.
    Assumes monotonicity (no defiers).

    Parameters
    ----------
    data_model : pd.DataFrame - must contain instrument and treatment columns
    instrument : str          - instrument column name ('offer')
    treatment  : str          - treatment column name ('takeup')

    Returns
    -------
    dict with keys: 'always_takers', 'never_takers', 'compliers', 'defiers',
                    'cell_counts' (pd.DataFrame of 2x2 counts)
    """
    # build the 2x2 frequency table of (offer, takeup) combinations
    cell_counts = (data_model
                   .groupby([instrument, treatment])
                   .size()
                   .unstack(fill_value=0))

    n = len(data_model)

    # always-takers are those who participate even without an offer (D=1 | Z=0)
    at_share = data_model.loc[data_model[instrument] == 0, treatment].mean()

    # never-takers are those who don't participate even when offered (D=0 | Z=1)
    nt_share = 1 - data_model.loc[data_model[instrument] == 1, treatment].mean()

    # under monotonicity, compliers = the first-stage difference
    # (the share whose participation was changed by the offer)
    comp_share = (data_model.loc[data_model[instrument] == 1, treatment].mean()
                  - data_model.loc[data_model[instrument] == 0, treatment].mean())

    # monotonicity rules out defiers by assumption
    defier_share = 0.0

    print('\n=== Compliance Type Shares ===')
    print(f'Always-takers : {at_share:.4f}  ({at_share*100:.1f}%)')
    print(f'Never-takers  : {nt_share:.4f}  ({nt_share*100:.1f}%)')
    print(f'Compliers     : {comp_share:.4f}  ({comp_share*100:.1f}%)')
    print(f'Defiers       : {defier_share:.1f}  (monotonicity assumed)\n')

    return {
        'always_takers': at_share,
        'never_takers':  nt_share,
        'compliers':     comp_share,
        'defiers':       defier_share,
        'cell_counts':   cell_counts
    }


def plot_compliance_types(compliance, instrument, treatment, path):
    """
    Produces a 1x3 figure matching the reference assignment:
      Left   - Pie chart of compliance type shares (Figure 5a style)
      Middle - 2x2 cell count bar chart (Figure 5b style)
      Right  - Group sizes within offered group (Figure 6 style)

    Parameters
    ----------
    compliance : dict    - from compute_compliance_types()
    instrument : str     - instrument column name
    treatment  : str     - treatment column name
    path       : Path    - directory to save output
    """
    at   = compliance['always_takers']
    nt   = compliance['never_takers']
    comp = compliance['compliers']
    cc   = compliance['cell_counts']

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle('Compliance types - Region A', fontsize=13)

    # left panel: pie chart of compliance shares
    ax = axes[0]
    labels_pie = [
        f'Always-takers\n({at*100:.1f}%)',
        f'Never-takers\n({nt*100:.1f}%)',
        f'Compliers\n({comp*100:.1f}%)',
        'Defiers\n(approx. 0%)'
    ]
    sizes  = [at, nt, comp, 0.0001]  # tiny value keeps the defier slice visible
    colors = ['#E07B54', '#888780', '#378ADD', '#D94F3D']
    wedges, texts = ax.pie(
        sizes, labels=labels_pie, colors=colors,
        startangle=90, wedgeprops={'edgecolor': 'white', 'linewidth': 1.2}
    )
    ax.set_title('Figure 5a - Compliance types\n(% of Region A population)',
                 fontsize=10)
    ax.annotate('Defiers approx. 0%\n(monotonicity assumed)',
                xy=(0.5, -0.08), xycoords='axes fraction',
                ha='center', fontsize=8, color='grey')

    # middle panel: 2x2 cell count bar chart
    ax = axes[1]
    cell_labels = ['Z=0,D=0\n(NT+comp.)', 'Z=0,D=1\n(AT)',
                   'Z=1,D=0\n(NT)',        'Z=1,D=1\n(AT+comp.)']
    cell_vals = [
        cc.loc[0, 0] if (0 in cc.index and 0 in cc.columns) else 0,
        cc.loc[0, 1] if (0 in cc.index and 1 in cc.columns) else 0,
        cc.loc[1, 0] if (1 in cc.index and 0 in cc.columns) else 0,
        cc.loc[1, 1] if (1 in cc.index and 1 in cc.columns) else 0,
    ]
    bar_colors = ['#888780', '#E07B54', '#888780', '#378ADD']
    bars = ax.bar(cell_labels, cell_vals, color=bar_colors,
                  edgecolor='black', width=0.5)
    # annotate each bar with the exact count
    for bar, val in zip(bars, cell_vals):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + max(cell_vals) * 0.01,
                str(int(val)), ha='center', va='bottom', fontsize=10)
    ax.set_ylabel('Count')
    ax.set_title('Figure 5b - 2x2 cell counts (Z, D)\n'
                 '(AT=always-taker, NT=never-taker, comp.=complier)',
                 fontsize=9)
    ax.set_ylim(0, max(cell_vals) * 1.15)

    # right panel: group sizes within offered group
    ax = axes[2]
    took_up  = cell_vals[3]   # Z=1, D=1: offered and participated
    did_not  = cell_vals[2]   # Z=1, D=0: offered but declined
    grp_labels = ['Took up\n(D=1, offered)', 'Did not\n(D=0, offered)']
    grp_vals   = [took_up, did_not]
    # orange for takers, grey for non-takers
    grp_colors = ['#E07B54', '#888780']
    bars2 = ax.bar(grp_labels, grp_vals, color=grp_colors,
                   edgecolor='black', width=0.4)
    for bar, val in zip(bars2, grp_vals):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + max(grp_vals) * 0.01,
                str(int(val)), ha='center', va='bottom', fontsize=11)
    ax.set_ylabel('Number of individuals')
    ax.set_title('Figure 6 - Group sizes within offered group\n(Region A, Z=1 only)',
                 fontsize=10)
    ax.set_ylim(0, max(grp_vals) * 1.15)

    plt.tight_layout()
    plt.savefig(str(path / 'compliance_types.png'), dpi=150, bbox_inches='tight')
    plt.show()


def plot_group_sizes(data_model, instrument, path):
    """
    Bar chart of group sizes: offered vs not offered (Figure 1 style).

    Parameters
    ----------
    data_model : pd.DataFrame
    instrument : str  - instrument column name
    path       : Path
    """
    # count how many individuals are in each group
    counts = data_model[instrument].value_counts().sort_index()
    labels = ['Not Offered\n(Z=0)', 'Offered\n(Z=1)']
    colors = ['#888780', '#378ADD']

    fig, ax = plt.subplots(figsize=(5, 5))
    bars = ax.bar(labels, counts.values, color=colors,
                  edgecolor='black', width=0.4)
    for bar, val in zip(bars, counts.values):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + counts.values.max() * 0.01,
                str(int(val)), ha='center', va='bottom', fontsize=12)
    ax.set_ylabel('Number of individuals')
    ax.set_title('Figure 1 - Group sizes: offered vs not offered\n(Region A)',
                 fontsize=10)
    ax.set_ylim(0, counts.values.max() * 1.15)
    plt.tight_layout()
    plt.savefig(str(path / 'group_sizes_offer.png'), dpi=150, bbox_inches='tight')
    plt.show()


def plot_standardised_balance(balance_df, group_col_offered, group_col_not,
                               stddiff_col, title, path, filename):
    """
    Two-panel figure for balance checks (Figure 2/3/8 style).
    Left panel: grouped horizontal bars showing means for BOTH groups
    (orange = offered/takers, grey = not-offered/non-takers).
    Right panel: standardised difference, bars > 10% flagged red.

    Parameters
    ----------
    balance_df        : pd.DataFrame - from iv_randomisation_check() or balance_check()
    group_col_offered : str  - column name for offered/treated group means
    group_col_not     : str  - column name for not-offered/control group means
    stddiff_col       : str  - column name for standardised difference values
    title             : str  - plot title
    path              : Path
    filename          : str  - output filename (no extension)
    """
    vars_    = balance_df.index.tolist()
    n_vars   = len(vars_)
    means_g1 = balance_df[group_col_offered].astype(float).values
    means_g2 = balance_df[group_col_not].astype(float).values
    # convert from percentage to proportion for the axis formatter
    diffs    = balance_df[stddiff_col].astype(float).values / 100

    fig, axes = plt.subplots(1, 2, figsize=(14, max(4, n_vars * 0.5)))

    # left panel: side-by-side bars showing the raw means for each group
    ax     = axes[0]
    y      = np.arange(n_vars)
    height = 0.35
    # offset the two groups slightly so they sit next to each other
    ax.barh(y + height / 2, means_g1, height=height,
            color='#E07B54', edgecolor='none', label=group_col_offered)
    ax.barh(y - height / 2, means_g2, height=height,
            color='#888780', edgecolor='none', label=group_col_not)
    ax.set_yticks(y)
    ax.set_yticklabels(vars_, fontsize=9)
    ax.set_xlabel('Standardised mean')
    ax.set_title('Standardised means by group', fontsize=10)
    ax.legend(fontsize=8, loc='lower right')
    ax.axvline(0, color='black', linewidth=0.6)

    # right panel: standardised differences with 10% threshold flagged
    ax = axes[1]
    # flag any variable where the groups differ by more than 10% of a pooled SD
    diff_colors = ['#D94F3D' if abs(d) > 0.10 else '#378ADD' for d in diffs]
    ax.barh(vars_, diffs, color=diff_colors, edgecolor='none', height=0.6)
    ax.axvline(0,     color='black', linewidth=0.8)
    ax.axvline( 0.10, color='red', linewidth=0.8, linestyle='--',
                alpha=0.5, label='10% threshold')
    ax.axvline(-0.10, color='red', linewidth=0.8, linestyle='--', alpha=0.5)
    ax.set_xlabel('Standardised difference (%)')
    ax.set_title('Standardised difference (>10% flagged red)', fontsize=10)
    ax.legend(fontsize=8)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x*100:.0f}%'))
    # variable names are already shown on the left panel, no need to repeat them
    ax.set_yticklabels([])

    fig.suptitle(title, fontsize=11)
    plt.tight_layout()
    plt.savefig(str(path / f'{filename}.png'), dpi=150, bbox_inches='tight')
    plt.show()


def plot_first_stage_annotated(data_model, instrument, treatment, path):
    """
    Enhanced first-stage bar chart showing take-up by offer status,
    with the first-stage difference (Delta) and F-statistic annotated
    (Figure 4 style from reference assignment).

    Parameters
    ----------
    data_model : pd.DataFrame
    instrument : str
    treatment  : str
    path       : Path
    """
    means  = data_model.groupby(instrument)[treatment].mean()
    d0_val = means[0]   # take-up rate among non-offered
    d1_val = means[1]   # take-up rate among offered
    delta  = d1_val - d0_val

    # quick approximation of the F-statistic using proportions and group sizes
    # this gives the same result as the full first-stage OLS when there are
    # no additional covariates
    n  = len(data_model)
    se = np.sqrt(d1_val * (1 - d1_val) / (data_model[instrument] == 1).sum()
               + d0_val * (1 - d0_val) / (data_model[instrument] == 0).sum())
    t_val = delta / se
    f_val = t_val ** 2

    fig, ax = plt.subplots(figsize=(6, 5))
    bars = ax.bar(['Not offered\n(Z=0)', 'Offered\n(Z=1)'],
                  [d0_val, d1_val],
                  color=['#888780', '#378ADD'],
                  edgecolor='black', width=0.4)

    # annotate the top of each bar with the percentage take-up rate
    for bar, val in zip(bars, [d0_val, d1_val]):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f'{val*100:.1f}%', ha='center', va='bottom',
                fontsize=11, fontweight='bold')

    # draw a double-headed arrow between the two bars to show the first-stage gap
    ax.annotate('', xy=(1, d1_val / 2), xytext=(0, d1_val / 2),
                arrowprops=dict(arrowstyle='<->', color='#D94F3D', lw=1.5))
    ax.text(0.5, d1_val / 2 + 0.01,
            f'Delta={delta:.3f}',
            ha='center', va='bottom', color='#D94F3D', fontsize=10)

    ax.set_ylabel('Take-up rate P(D=1)')
    ax.set_title(f'Figure 4 - First stage: take-up by offer status\n'
                 f'Diff = {delta:.3f}  |  F = {f_val:.0f}  (Region A)',
                 fontsize=10)
    ax.set_ylim(0, d1_val * 1.25)
    plt.tight_layout()
    plt.savefig(str(path / 'first_stage_annotated.png'), dpi=150,
                bbox_inches='tight')
    plt.show()


# ==============================================================================
# DOUBLY ROBUST ESTIMATOR
# Added for Part II.
#
# OFFER AS COVARIATE (Region A, Section 9):
# When calling my_dr() for Region A, pass a dataframe whose covariate columns
# include 'offer'. Both the propensity score model and the outcome regression
# will then condition on the instrument, making the CIA more plausible.
# This is controlled entirely from the main file via COVARIATES_CIA.
# ==============================================================================

def _outcome_regression(df, y_col, treat_col):
    """
    Fit separate OLS outcome models for treated and control using my_ols.
    Returns predicted potential outcomes mu1_hat, mu0_hat for all units.
    """
    exog_cols  = [c for c in df.columns if c not in [y_col, treat_col]]
    df_treat   = df[df[treat_col] == 1]
    df_control = df[df[treat_col] == 0]

    # fit the outcome model separately on treated units
    res_t  = my_ols(exog=df_treat[exog_cols], outcome=df_treat[y_col],
                    intercept=True, display=False)
    beta_t = res_t['coef'].values.reshape(-1, 1)

    # fit the outcome model separately on control units
    res_c  = my_ols(exog=df_control[exog_cols], outcome=df_control[y_col],
                    intercept=True, display=False)
    beta_c = res_c['coef'].values.reshape(-1, 1)

    # predict potential outcomes for everyone using both models
    # the intercept column has to be prepended to match the my_ols convention
    X_all   = np.hstack([np.ones((df.shape[0], 1)), df[exog_cols].values])
    mu1_hat = (X_all @ beta_t).flatten()   # predicted Y(1) for all units
    mu0_hat = (X_all @ beta_c).flatten()   # predicted Y(0) for all units
    return mu1_hat, mu0_hat


def _dr_formula(treat, outcome, pscores, mu1_hat, mu0_hat):
    """Classic doubly robust ATE formula."""
    # the DR formula combines IPW correction with outcome model predictions
    # it stays consistent if either the propensity score OR the outcome model is right
    dr = (treat * (outcome - mu1_hat) / pscores
          - (1 - treat) * (outcome - mu0_hat) / (1 - pscores)
          + mu1_hat - mu0_hat)
    return np.mean(dr)


def ate_dr(df, y_col, treat_col, intercept=True):
    """
    Doubly Robust ATE point estimate.

    Parameters
    ----------
    df         : pd.DataFrame - must contain covariates, treatment, outcome.
                 For Region A (Section 9): include 'offer' in the covariate
                 columns so both the PS model and outcome model condition on it.
    y_col      : str - outcome column name
    treat_col  : str - treatment column name
    intercept  : bool

    Returns
    -------
    ate, pscores, mu1_hat, mu0_hat
    """
    # everything except the outcome and treatment goes into the covariate matrix
    exog_cols = [c for c in df.columns if c not in [y_col, treat_col]]
    exog      = df[exog_cols]

    # estimate propensity scores using logistic regression
    if intercept:
        pscores = sm.Logit(endog=df[treat_col],
                           exog=sm.add_constant(exog)).fit(disp=0).predict()
    else:
        pscores = sm.Logit(endog=df[treat_col], exog=exog).fit(disp=0).predict()

    # get the predicted potential outcomes from the outcome regression
    mu1_hat, mu0_hat = _outcome_regression(df, y_col, treat_col)

    # plug everything into the DR formula
    ate = _dr_formula(df[treat_col].values, df[y_col].values,
                  np.array(pscores), mu1_hat, mu0_hat)
    return ate, pscores, mu1_hat, mu0_hat


def _ate_dr_boot(df, y_col, treat_col, intercept=True, reps=100):
    """Bootstrap SEs for DR ATE."""
    rng      = np.random.default_rng(12345)
    ate_boot = []
    for i in range(reps):
        # resample rows with replacement and reset the index so my_ols works cleanly
        idx     = rng.choice(df.index, size=df.shape[0], replace=True)
        df_boot = df.loc[idx].reset_index(drop=True)
        try:
            val, _, _, _ = ate_dr(df_boot, y_col, treat_col, intercept=intercept)
            ate_boot.append(val)
        except Exception:
            # occasionally a bootstrap sample may cause the logit not to converge
            # we skip those replications rather than crashing the whole loop
            continue
    if not ate_boot:
        raise ValueError("All DR bootstrap replications failed.")
    # bootstrap SE is the standard deviation across all successful replications
    return np.std(ate_boot)


def my_dr(df, y_col, treat_col, intercept=True, display=True, boot=100):
    """
    Doubly Robust ATE estimation with bootstrap SEs.

    Parameters
    ----------
    df        : pd.DataFrame - covariates + treatment + outcome.
                For Region A: df = data_model_A[COVARIATES_CIA + [TREATMENT, OUTCOME]]
                where COVARIATES_CIA = BASE_COVARIATES + ['offer'].
    y_col     : str - outcome column
    treat_col : str - treatment column
    intercept : bool
    display   : bool
    boot      : int - bootstrap replications

    Returns
    -------
    pd.DataFrame - result with coef, se, t-value, p-value
    """
    # get the point estimate
    ate, _, _, _ = ate_dr(df, y_col, treat_col, intercept=intercept)
    # get the SE via bootstrapping
    ate_se       = _ate_dr_boot(df, y_col, treat_col, intercept=intercept, reps=boot)

    tval = ate / ate_se
    # degrees of freedom: N minus the number of covariates (outcome and treatment
    # are not counted since they are not regressors in the usual sense)
    n, k = df.shape[0], df.shape[1] - 2
    pval = stats.t.sf(np.abs(tval), n - k) * 2

    result = pd.DataFrame([ate, ate_se, tval, pval],
                          index=['coef', 'se', 't-value', 'p-value'],
                          columns=[treat_col]).transpose()

    if display:
        print('Doubly Robust Estimation Results:', '-' * 80,
              'Dependent Variable: ' + y_col, '-' * 80,
              round(result, 2), '-' * 80, '\n\n', sep='\n')
    return result