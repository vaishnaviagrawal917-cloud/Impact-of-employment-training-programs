"""
Data Analytics II: Self Study 1
University of St. Gallen
Vaishnavi Agrawal
"""



import os
os.chdir(r'C:\Users\Vaishnavi\OneDrive\Desktop\Python Projects\Self Study Project- Vaishnavi Agrawal')
import sys
import importlib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import selfstudy_functions as f
importlib.reload(f)

# ============================================================
# SETUP
# ============================================================
PATH = os.getcwd()
print(PATH)
DATANAME = 'data_2.csv'

# ============================================================
# PART 1: DATA PREPARATION
# ============================================================

# Loading raw data
data_raw = pd.read_csv(PATH + '/' + DATANAME)

# Dropping missing values
data_raw = data_raw.dropna()

# Cleaning data
data_clean = f.clean_data(data_raw)
region_labels = data_clean['region'].copy()

# Create dummies
data_model = f.make_dummies(data_clean)

# Adding region labels back for EDA
data_clean['region'] = region_labels
data_model['region'] = region_labels.loc[data_model.index]
data_clean.to_csv(str(Path(PATH) / 'data_clean.csv'), index=False)

# ============================================================
# PART 2: EXPLORATORY DATA ANALYSIS
# ============================================================

continuous = ['age', 'baseline_income', 'unemp_duration', 'language_score']
binary = ['gender', 'immigrant', 'disability', 
          'employment_gaps', 'special_trainings']

# Summary tables
desc_stats= f.descriptive_stats(data_clean, continuous, PATH)
desc_stats.to_csv(Path(PATH) / 'descriptive_stats.csv')
binary_stats =f.binary_stats(data_clean, binary, PATH)
binary_stats.to_csv(Path(PATH) / 'binary_stats.csv')
treatment_stats =f.treatment_stats(data_clean, PATH)
treatment_stats.to_csv(Path(PATH) / 'treatment_stats.csv')

# Visualizations
f.plot_continuous(data_clean, continuous, PATH)
f.plot_binary(data_clean, binary, PATH)
f.plot_outcome(data_clean, PATH)
f.plot_treatment(data_clean, PATH)
f.plot_education(data_clean, PATH)
f.plot_language_score(data_clean, PATH)

# Running separately for each region

print(data_model['takeup'].unique())
print(data_model['takeup'].isna().sum())
data_model['takeup'] = data_model['takeup'].replace(99, float('nan'))
data_clean['takeup'] = data_clean['takeup'].replace(99, float('nan'))


treatment_by_region = {
    'A': 'offer',
    'B': 'takeup',
    'C': 'takeup'
}

overlap_rows = []

for region in ['A', 'B', 'C']:
    print(f"\n=== Region {region} ===")
    subset = data_model[data_model['region'] == region].copy()
    
    treatment_col = treatment_by_region[region]
    
    # Step 1 - Defining covariate columns
    covariate_cols = [col for col in subset.columns 
                      if col not in ['outcome', 'offer', 'takeup', 'region']]
    
    # Explicitly filtering out NaN values in treatment column
    subset = subset[subset[treatment_col].notna()]
    subset[treatment_col] = subset[treatment_col].astype(int)
    
    # Step 2 - Dropping constant columns HERE (region dummies become constant within each region)
    covariate_cols = [col for col in covariate_cols 
                      if subset[col].std() > 0]
    
    # Step 3 - Passing to common_support
    exog = subset[covariate_cols]
    treat = subset[treatment_col]
    
    print(f"Treatment variable: {treatment_col}")
    print(f"Treatment rate: {treat.mean():.3f}")
    print(f"Treated: {int(treat.sum())}, Control: {int((treat==0).sum())}")
    
    #Checking the overlap and common support
    try:
        overlap_idx = f.common_support(
            exog=exog,
            treat=treat,
            path=Path(PATH),
            bins=10,
            enforce= True,
            region= region
        )
        print(f"Observations on support: {len(overlap_idx)}")
    
    except np.linalg.LinAlgError:
        print(f"Singular matrix : overlap cannot be estimated for Region {region}.")

    # numerical check 
    try:
        # estimate propensity scores
        import statsmodels.api as sm
        pscores = pd.Series(
            sm.Logit(endog=treat, exog=sm.add_constant(exog)).fit(disp=0).predict(),
            index=exog.index
        )
        treated_ps = pscores[treat == 1]
        control_ps = pscores[treat == 0]
        lower = max(treated_ps.min(), control_ps.min())
        upper = min(treated_ps.max(), control_ps.max())
        inside  = ((pscores >= lower) & (pscores <= upper)).sum()
        outside = len(pscores) - inside

        
        overlap_rows.append({
            'Region': region, 'Group': 'Treated',
            'N': len(treated_ps),
            'Mean PS': round(treated_ps.mean(), 3),
            'Std PS':  round(treated_ps.std(),  3),
            'Min PS':  round(treated_ps.min(),  3),
            'Max PS':  round(treated_ps.max(),  3),
            'Support lower': round(lower, 3),
            'Support upper': round(upper, 3),
            'Inside support': inside,
            'Outside support': outside
        })
        overlap_rows.append({
            'Region': region, 'Group': 'Control',
            'N': len(control_ps),
            'Mean PS': round(control_ps.mean(), 3),
            'Std PS':  round(control_ps.std(),  3),
            'Min PS':  round(control_ps.min(),  3),
            'Max PS':  round(control_ps.max(),  3),
            'Support lower': round(lower, 3),
            'Support upper': round(upper, 3),
            'Inside support': inside,
            'Outside support': outside
        })

        f.overlap_numerical(exog, treat, region)

    except np.linalg.LinAlgError:
        print(f"Singular matrix — numerical overlap cannot be estimated for Region {region}.")

# ── Saving combined numerical overlap table ─────────────────────────────────────
overlap_df = pd.DataFrame(overlap_rows)
overlap_df.to_csv(Path(PATH) / 'overlap_numerical.csv', index=False)
print("\nAll tables and figures saved.")

# ============================================================
# PART 3: ESTIMATION UNDER SELECTION ON OBSERVABLES

results_all = {}
for region in ['A', 'B']:
    print(f"\n{'='*60}")
    print(f"REGION {region}")
    print(f"{'='*60}")
    
    subset = data_model[data_model['region'] == region].copy()
    treatment_col = treatment_by_region[region]
    subset = subset[subset[treatment_col].notna()]
    subset[treatment_col] = subset[treatment_col].astype(int)
    
    covariate_cols = [col for col in subset.columns
                      if col not in ['outcome', 'offer', 'takeup', 'region']]
    covariate_cols = [col for col in covariate_cols
                      if subset[col].std() > 0]
    
    exog  = subset[covariate_cols]
    treat = subset[treatment_col]
    outcome = subset['outcome']

    #Method 1: Raw Mean Differences 
    print("\n--- Method 1: Raw Mean Differences ---")
    result_md = f.ate_md(outcome=outcome, treatment=treat)

    #Method 2: Regression Adjustment (OLS with controls)
    print("\n--- Method 2: Regression Adjustment ---")
    exog_ols = pd.concat([treat, exog], axis=1)   # treatment + covariates
    result_ols = f.my_ols(exog=exog_ols, outcome=outcome)

    #Method 3: IPW 
    print("\n--- Method 3: IPW ---")
    result_ipw = f.my_ipw(
        exog=exog,
        outcome=outcome,
        treat=treat,
        intercept=True,
        boot=1000          # increase bootstrap reps for stable SE
    )

    #Method 4: Doubly Robust 
    print("\n--- Method 4: Doubly Robust ---")
    result_dr = f.my_ipw(
        exog=exog,
        outcome=outcome,
        treat=treat,
        intercept=True,
        boot=500,
        lasso=True,       # lasso propensity score = doubly robust
        cval=True         # cross-validated penalty
    )

    results_all[region] = {
        'md':  result_md,
        'ols': result_ols,
        'ipw': result_ipw,
        'dr':  result_dr
    }
    
rows = []

#Combing the results into one table
for region, methods in results_all.items():
    treatment_col = treatment_by_region[region]  # 'offer' or 'takeup'
    
    for method_name, result in methods.items():
        
        if method_name == 'md':
            row = result.loc['MeanDiff']
            ate     = round(row['ATE'],     4)
            se      = round(row['SE'],      4)
            t_value = round(row['t-value'], 4)
            p_value = round(row['p-value'], 4)
            
        elif method_name == 'ols':
            row = result.loc[treatment_col]   # picks 'offer' or 'takeup' row
            ate     = round(row['coef'],     4)
            se      = round(row['se'],       4)
            t_value = round(row['t-value'],  4)
            p_value = round(row['p-value'],  4)
            
        else:  # ipw and dr
            row = result.loc[treatment_col]
            ate     = round(row['coef'],     4)
            se      = round(row['se'],       4)
            t_value = round(row['t-value'],  4)
            p_value = round(row['p-value'],  4)

        rows.append({
            'Region':  region,
            'Method':  method_name,
            'ATE':     ate,
            'SE':      se,
            't_value': t_value,
            'p_value': p_value,
        })

df_results = pd.DataFrame(rows)
print(df_results)
df_results.to_csv(str(Path(PATH) / 'results_all.csv'), index=False)


# ============================================================

# PART 4: CREDIBILITY OF THE CIA (Balance Check within Regions)

for region in ['A', 'B', 'C']:
    print(f"\n=== Balance Check - Region {region} ===")
    
    subset = data_model[data_model['region'] == region].copy()
    treatment_col = treatment_by_region[region]  
    subset = subset[subset[treatment_col].notna()]
    subset[treatment_col] = subset[treatment_col].astype(int)
    variables = [col for col in subset.columns
                 if col not in ['outcome', 'offer', 'takeup', 'region']]
    variables = [col for col in variables if subset[col].std() > 0]
    balance_self = f.balance_check(data=subset,
                                   treatment=treatment_col,
                                   variables=variables)
    balance_self = balance_self.round(2)
    balance_self.to_csv(Path(PATH) / f'balance_check_region_{region}.csv')
    
