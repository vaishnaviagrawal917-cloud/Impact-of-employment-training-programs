"""
Self Study Functions File
Data Analytics II
University of St. Gallen
Vaishnavi Agrawal
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import statsmodels.api as sm
from scipy import stats
from sklearn import linear_model


def clean_data(data):
    """
    Cleans raw data by standardising region and education labels,
    converting age to numeric, and removing outliers.
    Parameters
    ----------
    data : pd.DataFrame
    Returns
    -------
    pd.DataFrame — cleaned dataframe
    """
    data = data.copy()

    # Fix region
    region_map = {
        'A': 'A', 'Region A': 'A', 'a': 'A', 'A ': 'A',
        'B': 'B', 'Region B': 'B', 'B-': 'B', 'b': 'B',
        'C': 'C', 'Region C': 'C', 'C_': 'C', 'c': 'C'
    }
    data['region'] = data['region'].map(region_map)

    # Fix education
    education_map = {
        '0': 'Low', 'low': 'Low', 'LOW': 'Low',
        '1': 'Medium', 'Medium': 'Medium', 'med': 'Medium',
        '2': 'High', 'High': 'High', 'H': 'High',
        '3': 'Tertiary', 'Tertiary': 'Tertiary', 'uni': 'Tertiary'
    }
    data['education'] = data['education'].map(education_map)

    # Fix age
    data['age'] = pd.to_numeric(data['age'], errors='coerce').round(1)

    # Drop post-treatment variables and id
    post_treatment_vars = [
        'active_participation',
        'course_hours_completed', 'diploma_awarded', 'id'
    ]
    data = data.drop(columns=post_treatment_vars)

    # Replace 999 sentinel values
    for col in ['age', 'unemp_duration', 'baseline_income']:
        data[col] = data[col].replace(999.0, float('nan'))
        data['takeup'] = data['takeup'].replace(99, float('nan'))
    # Remove impossible values
    data = data[(data['age'] >= 18) & (data['age'] <= 80)]
    data = data[data['unemp_duration'] >= 0]
    data = data[data['baseline_income'] <= 150000]

    # Drop remaining NaNs
    data = data.dropna()

    return data


def make_dummies(data):
    """
    Creates dummy variables for region and education.
    Saves region labels before conversion for EDA use.
    Parameters
    ----------
    data : pd.DataFrame
    Returns
    -------
    pd.DataFrame — dataframe with dummies
    """
    data = pd.get_dummies(data, columns=['region'], drop_first=True)
    data = pd.get_dummies(data, columns=['education'], drop_first=True)
    data = data.astype({
        col: int for col in data.select_dtypes(include='bool').columns
    })
    return data


def descriptive_stats(data, continuous, path):
    """
    Computes descriptive statistics of continuous variables by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    continuous : list of strings — continuous variable names
    path : string — path to save output
    Returns
    -------
    pd.DataFrame — descriptive statistics table
    """
    rows = []
    for region in ['A', 'B', 'C']:
        subset = data[data['region'] == region]
        for col in continuous:
            rows.append({
                'Region': region,
                'Variable': col,
                'Count': subset[col].count(),
                'Mean': subset[col].mean().round(2),
                'Std': subset[col].std().round(2),
                'Min': subset[col].min().round(2),
                'Median': subset[col].median().round(2),
                'Max': subset[col].max().round(2)
            })

    desc_stats = pd.DataFrame(rows).set_index(['Region', 'Variable'])
    print("=== Descriptive Statistics of Continuous Variables by Region ===")
    print(desc_stats.to_string())
    desc_stats.to_csv(str(Path(path) / 'descriptive_stats_by_region.csv'))

    return desc_stats


def binary_stats(data, binary, path):
    """
    Computes proportions of binary variables by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    binary : list of strings — binary variable names
    path : string — path to save output
    Returns
    -------
    pd.DataFrame — binary proportions table
    """
    stats = data.groupby('region')[binary].mean().round(3)
    stats['n_obs'] = data.groupby('region').size()
    print("\n=== Proportions of Binary Variables by Region ===")
    print(stats.to_string())
    stats.to_csv(str(Path(path) / 'binary_stats_by_region.csv'))

    return stats


def treatment_stats(data, path):
    """
    Computes offer and takeup rates by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    path : string — path to save output
    Returns
    -------
    pd.DataFrame — treatment statistics table
    """
    stats = data.groupby('region')[['offer', 'takeup']].mean().round(3)
    stats['n_obs'] = data.groupby('region').size()
    print("\n=== Treatment Offer and Takeup Rates by Region ===")
    print(stats.to_string())
    stats.to_csv(str(Path(path) / 'treatment_stats_by_region.csv'))

    return stats


def plot_continuous(data, continuous, path):
    """
    Plots boxplots of continuous variables by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    continuous : list of strings
    path : string
    """
    fig, axes = plt.subplots(1, len(continuous), figsize=(15, 5))
    for ax, col in zip(axes, continuous):
        sns.boxplot(data=data, x='region', y=col, ax=ax, palette='Set2')
        ax.set_title(f'{col} by Region')
        ax.set_xlabel('Region')
        ax.set_ylabel(col)
    plt.suptitle('Continuous Variable Distributions by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'boxplots_continuous.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_binary(data, binary, path):
    """
    Plots bar charts of binary variable proportions by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    binary : list of strings
    path : string
    """
    fig, axes = plt.subplots(1, len(binary), figsize=(18, 5))
    for ax, col in zip(axes, binary):
        data.groupby('region')[col].mean().plot(
            kind='bar', ax=ax, color='steelblue', edgecolor='black')
        ax.set_title(col)
        ax.set_xlabel('Region')
        ax.set_ylabel('Proportion')
        ax.set_xticklabels(['A', 'B', 'C'], rotation=0)
    plt.suptitle('Binary Variable Proportions by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'binary_proportions.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_outcome(data, path):
    """
    Plots outcome distribution by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    path : string
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, region in zip(axes, ['A', 'B', 'C']):
        subset = data[data['region'] == region]['outcome']
        ax.hist(subset, bins=30, color='steelblue', edgecolor='black')
        ax.axvline(subset.mean(), color='red', linestyle='--',
                   label=f'Mean: {subset.mean():.0f}')
        ax.set_title(f'Outcome - Region {region}')
        ax.set_xlabel('Outcome')
        ax.set_ylabel('Frequency')
        ax.legend()
    plt.suptitle('Outcome Distribution by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'outcome_distribution.png'),
                dpi=150, bbox_inches='tight')
    plt.show()


def plot_treatment(data, path):
    """
    Plots offer and takeup rates by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    path : string
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    treatment_plot = data.groupby('region')[['offer', 'takeup']].mean()
    treatment_plot.plot(kind='bar', ax=ax,
                        color=['steelblue', 'coral'], edgecolor='black')
    ax.set_title('Treatment Offer and Takeup Rates by Region')
    ax.set_xlabel('Region')
    ax.set_ylabel('Proportion')
    ax.set_xticklabels(['A', 'B', 'C'], rotation=0)
    ax.legend(['Offer Rate', 'Takeup Rate'])
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'treatment_rates.png'),
                dpi=150, bbox_inches='tight')
    plt.show()
    
def plot_education(data, path):
    """
    Plots education distribution by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    path : string
    """
    fig, ax = plt.subplots(figsize=(10, 5))
    edu_counts = data.groupby(['region', 'education']).size().unstack(fill_value=0)
    edu_counts.plot(kind='bar', ax=ax, edgecolor='black')
    ax.set_title('Education Distribution by Region')
    ax.set_xlabel('Region')
    ax.set_ylabel('Count')
    ax.set_xticklabels(['A', 'B', 'C'], rotation=0)
    ax.legend(title='Education')
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'education_by_region.png'),
                dpi=150, bbox_inches='tight')
    plt.show()
    

def plot_language_score(data, path):
    """
    Plots language score distribution by region.
    Parameters
    ----------
    data : pd.DataFrame — must contain original region labels
    path : string
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, region in zip(axes, ['A', 'B', 'C']):
        subset = data[data['region'] == region]['language_score']
        ax.hist(subset, bins=30, color='yellow', edgecolor='black')
        ax.axvline(subset.mean(), color='red', linestyle='--',
                   label=f'Mean: {subset.mean():.2f}')
        ax.set_title(f'Language Score - Region {region}')
        ax.set_xlabel('Language Score')
        ax.set_ylabel('Frequency')
        ax.legend()
    plt.suptitle('Language Score Distribution by Region', fontsize=14)
    plt.tight_layout()
    plt.savefig(str(Path(path) / 'language_score_distribution.png'),
                dpi=150, bbox_inches='tight')
    plt.show()

    
def common_support(exog, treat, path, bins=10, enforce=False, region=''):
    """
    Check and enforce common support.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    path : TYPE: string
        DESCRIPTION: path where the plot will be saved
    bins : TYPE: integer, optional
        DESCRIPTION: number of bins for the histogram.
        The default is 10.
    enforce : TYPE: boolean, optional
        DESCRIPTION: if common support should be enforced.
        The default is False.

    Returns
    -------
    result: Array of indices for overlap observations and plots/saves
    a common support histogram.

    """
    # estimate the propensity scores via logit and extract the predictions
    # use the statsmodels module and its Logit() command
    pscores = pd.Series(sm.Logit(
        endog=treat, exog=sm.add_constant(exog)).fit(disp=0).predict(),
        index=exog.index)
    # get the pscores for respective treatment status
    # use the by logical vector of True/False for the subsetting
    pscores_d0 = pscores[treat == 0]
    pscores_d1 = pscores[treat == 1]
    # plot the histograms for treated and control using matplotlib module
    plt.hist(pscores_d0, bins=bins, color='green', alpha=0.5, label='control')
    plt.hist(pscores_d1, bins=bins, color='black', alpha=0.5, label='treated')
    # add legend to the 'best' position
    plt.legend(loc='best')
    # add labels and title
    plt.title(f'Histogram of Propensity Scores for Treated and Controls - Region {region}')
    plt.xlabel('Propensity Score')
    plt.ylabel('Counts')
    plt.grid(axis='y', alpha=0.75)
    # save the plot under the path specified
    plt.savefig(path / f'histogram_of_pscores_region_{region}.png')
    # print the plot
    plt.show()
    # check if the common support should be enforced
    # the following condition checks implicitly if enforce == True
    if enforce:
        # if True, get indices for treated and control
        indices_d0 = exog.index[treat == 0]
        indices_d1 = exog.index[treat == 1]
        # get the min and max values of the pscores for the corresponding idx
        min_pscores_d0 = np.amin(pscores[indices_d0])
        max_pscores_d0 = np.amax(pscores[indices_d0])
        min_pscores_d1 = np.amin(pscores[indices_d1])
        max_pscores_d1 = np.amax(pscores[indices_d1])
        # filter out the values that are on support
        d0_cs = ((pscores[indices_d0] >= min_pscores_d1) &
                 (pscores[indices_d0] <= max_pscores_d1))
        d1_cs = ((pscores[indices_d1] >= min_pscores_d0) &
                 (pscores[indices_d1] <= max_pscores_d0))
        indices_d0_cs = indices_d0[d0_cs]
        indices_d1_cs = indices_d1[d1_cs]
        # return the indices for observations on support
        # concatenate the indices for treated and controls and sort them
        overlap = np.sort(np.concatenate((indices_d0_cs, indices_d1_cs),
                                         axis=0))
    else:
        # if False, nothing is cut off due to support issues
        # overlap stays the same as the original indices
        overlap = exog.index
    # check how many are not in support? compare the number of observations
    print('Number of observations off support: ',
          f'{len(exog) - len(overlap)}', '\n\n')
    # return result
    return overlap

def overlap_numerical(exog, treat, region):
    """
    Numerically checks overlap by computing propensity score
    statistics for treated and control groups.
    Parameters
    ----------
    exog : pd.DataFrame — covariate matrix
    treat : pd.Series — treatment variable
    region : string — region label for printing
    """
    # Estimate propensity scores
    pscores = pd.Series(
        sm.Logit(endog=treat, exog=sm.add_constant(exog)).fit(disp=0).predict(),
        index=exog.index
    )

    treated_ps = pscores[treat == 1]
    control_ps = pscores[treat == 0]

    # Common support bounds
    lower = max(treated_ps.min(), control_ps.min())
    upper = min(treated_ps.max(), control_ps.max())

    # Observations inside and outside support
    inside = ((pscores >= lower) & (pscores <= upper)).sum()
    outside = len(pscores) - inside

    # Summary table
    results = pd.DataFrame({
        'Group': ['Treated', 'Control'],
        'N': [len(treated_ps), len(control_ps)],
        'Mean PS': [treated_ps.mean().round(3), control_ps.mean().round(3)],
        'Std PS':  [treated_ps.std().round(3),  control_ps.std().round(3)],
        'Min PS':  [treated_ps.min().round(3),  control_ps.min().round(3)],
        'Max PS':  [treated_ps.max().round(3),  control_ps.max().round(3)]
    })

    print(f"\n=== Numerical Overlap Check - Region {region} ===")
    print(results.to_string(index=False))
    print(f"\nCommon support: [{lower:.3f}, {upper:.3f}]")
    print(f"Inside support:  {inside}  ({100*inside/len(pscores):.1f}%)")
    print(f"Outside support: {outside} ({100*outside/len(pscores):.1f}%)")
    
# ATE estimation by mean differences
def ate_md(outcome, treatment):
    """
    Estimate ATE by differences in means.

    Parameters
    ----------
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treatment : TYPE: pd.Series
        DESCRIPTION: vector of treatments

    Returns
    -------
    results : ATE with Standard Error
    """
    # outcomes y according to treatment status by logical vector of True/False
    # set treated and control apart using the location for subsetting
    # using the .loc both labels as well as booleans are allowed
    y_1 = outcome.loc[treatment == 1]
    y_0 = outcome.loc[treatment == 0]
    # compute ATE and its standard error and t-value
    ate = y_1.mean() - y_0.mean()
    ate_se = np.sqrt(y_1.var() / len(y_1) + y_0.var() / len(y_0))
    ate_tval = ate / ate_se
    # compute pvalues based on the normal distribution (requires scipy)
    # sf stands for the survival function (also defined as 1 - cdf)
    ate_pval = stats.norm.sf(abs(ate_tval)) * 2  # twosided
    # alternatively ttest_ind() could be used directly
    # stats.ttest_ind(a=y_1, b=y_0, equal_var=False)
    # convert the dictionary to dataframe for a nicer output and name rows
    # pandas dataframe will automatically take the keys as columns if the
    # data input is a dictionary. Transpose for having the stats as columns
    result = pd.DataFrame([ate, ate_se, ate_tval, ate_pval],
                          index=['ATE', 'SE', 't-value', 'p-value'],
                          columns=['MeanDiff']).transpose()
    # return and print result (\n inserts a line break)
    print('ATE Estimate by Difference in Means:', '-' * 80,
          'Dependent Variable: ' + outcome.name, '-' * 80,
          round(result, 2), '-' * 80, '\n\n', sep='\n')
    # return the resulting dataframe too
    return result


# use own ols procedure
def my_ols(exog, outcome, intercept=True, display=True):
    """
    OLS estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: outcome
    intercept : TYPE: boolean
        DESCRIPTION: should intercept be included? The default is True.
    display : TYPE: boolean
        DESCRIPTION: should results be displayed? The default is True.

    Returns
    -------
    result: ols estimates with standard errors
    """
    # check if intercept should be included
    # the following condition checks implicitly if intercept == True
    if intercept:
        # if True, prepend a vector of ones to the covariate matrix
        exog = pd.concat([pd.Series(np.ones(len(exog)), index=exog.index,
                                    name='intercept'), exog], axis=1)
    # compute (x'x)-1 by using the linear algebra from numpy

    x_inv = np.linalg.inv(np.dot(exog.T, exog))
    # estimate betas according to the OLS formula b=(x'x)^(-1)(x'y)
    betas = np.dot(x_inv, np.dot(exog.T, outcome))
    # compute the residuals by subtracting fitted values from the outcomes
    res = outcome - np.dot(exog, betas)
    # estimate standard errors for the beta coefficients
    # se = square root of diag((u'u)(x'x)^(-1)/(N-p))
    s_e = np.sqrt(np.diagonal(np.dot(np.dot(res.T, res), x_inv) /
                              (exog.shape[0] - exog.shape[1])))
    # compute the t-values
    tval = betas / s_e
    # compute pvalues based on the students t-distribution (requires scipy)
    # sf stands for the survival function (also defined as 1 - cdf)
    # degrees of freedom as N - p using the shape method of pandas
    pval = stats.t.sf(np.abs(tval),
                      (exog.shape[0] - exog.shape[1])) * 2
    # put results into dataframe and name the corresponding values
    result = pd.DataFrame([betas, s_e, tval, pval],
                          index=['coef', 'se', 't-value', 'p-value'],
                          columns=list(exog.columns.values)).transpose()
    # check if the results should be printed to the console
    # the following condition checks implicitly if display == True
    if display:
        # if True, print the results (\n inserts a line break)
        print('OLS Estimation Results:', '-' * 80,
              'Dependent Variable: ' + outcome.name, '-' * 80,
              round(result, 2), '-' * 80, '\n\n', sep='\n')
    # return the resulting dataframe too
    return result


# ipw formula
def ipw_formula(treat, outcome, prob, normalize=True):
    """
    IPW formula.

    Parameters
    ----------
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    prob : TYPE: pd.Series / array
        DESCRIPTION: vector of probabilities

    Returns
    -------
    result: ATE estimate according to IPW
    """
    # compute ate based on ipw formula, take the mean using numpy
    # This is the standard version - known to have bad  small sample properties
    if not normalize:
        ate = np.mean(treat * outcome / prob
                      - (1 - treat) * outcome / (1 - prob))
    else:
        # We can achieve better small sample properties if we normalize
        # the weights for treated and controls
        w_1 = treat / prob
        w_0 = (1 - treat) / (1 - prob)
        w_1 = w_1 / np.sum(w_1)
        w_0 = w_0 / np.sum(w_0)
        ate = np.sum(w_1 * outcome) - np.sum(w_0 * outcome)
    # return the result
    return ate


# ipw ate estimation
def ate_ipw(exog, outcome, treat,
            intercept=True, lasso=False, cval=False, folds=10):
    """
    ATE estimation by IPW.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    intercept : TYPE: boolean, optional
        DESCRIPTION: if intercept should be used.
        The default is True.
    lasso : TYPE: boolean, optional
        DESCRIPTION: if lasso should be used for propensity score.
        The default is False.
    cval : TYPE: boolean, optional
        DESCRIPTION: if cross-validation should be used for lasso.
        The default is False.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cross-validation.
        The default is 10.

    Returns
    -------
    result: ATE estimate according to IPW with logit propensity scores
    """
    # check if lasso should be used for propensity scores
    # the following condition checks implicitly if lasso == True
    if lasso:
        # check if cv should be used for lasso penalty
        # the following condition checks implicitly if cval == True
        if cval:
            # estimate propensity scores via lasso with cv penalty
            # and extract the predictions directly from the output
            pscores = my_cv_lasso(exog=exog, outcome=treat,
                                  intercept=intercept,
                                  folds=folds)['predictions']
        else:
            # check if intercept should be included
            # the following condition checks implicitly if intercept == True
            if intercept:
                # if True, prepend a vector of ones to the covariate matrix
                # directly using the add_constant function from statsmodels
                # estimate propensity scores via lasso without tuning
                # use the fit_regularized() function from the statsmodels
                # and predict the probabilities directly
                pscores = sm.OLS(endog=treat,
                                 exog=sm.add_constant(exog)).fit_regularized(
                                     ).predict()
            else:
                # if False, no intercept when estimating pscores
                # estimate propensity scores via lasso without tuning
                # use the fit_regularized() function from the statsmodels
                pscores = sm.OLS(endog=treat,
                                 exog=exog).fit_regularized().predict()
    else:
        # if lasso == False, lasso should not be used
        # estimate propensity scores via logit and extract the predictions
        # use the Logit() function from the statsmodels module
        # chekc if intercept should be included
        # the following condition checks implicitly if intercept == True
        if intercept:
            pscores = sm.Logit(endog=treat, exog=sm.add_constant(exog)).fit(
                disp=0).predict()
        else:
            # if False, no intercept when estimating pscores
            pscores = sm.Logit(endog=treat, exog=exog).fit(disp=0).predict()
    # finally compute ate based on ipw formula and feed in the pscores
    ate = ipw_formula(treat=treat, outcome=outcome, prob=pscores)
    # return the result
    return ate, pscores


# standard errors via bootstrap for ipw ate estimate
def ate_ipw_boot(exog, outcome, treat, intercept=True,
                 reps=100, lasso=False, cval=False, folds=10):
    """
    Bootstrap Standard Errors for IPW Estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    intercept : TYPE: boolean, optional
        DESCRIPTION: if intercept should be used.
        The default is True.
    reps : TYPE: integer, optional
        DESCRIPTION: Number of bootstrap replications for inference.
        The default is 100.
    lasso : TYPE: boolean, optional
        DESCRIPTION: if lasso should be used for propensity score.
        The default is False.
    cv : TYPE: boolean, optional
        DESCRIPTION: if cross-validation should be used for lasso.
        The default is False.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cross-validation.
        The default is 10.

    Returns
    -------
    result: bootstrap standard error for ATE
    """
    # create storage for the bootstrap estimates as an empty dictionary
    # to easily fill in values including the corresponding names
    ate_boot = np.empty(reps)
    # Initialize the numpy random number generator for replicability of results
    rng = np.random.default_rng(12345)
    # loop over replications, use the range function: 0,...,reps-1
    for rep_id in range(reps):
        # take a bootstrap sample from original data
        # randomly choose observations indices with replacement
        boot_sample = rng.choice(exog.index, size=exog.shape[0], replace=True)
        # subset the original data with bootstrap indices using the loc method
        # here we choose the observations based on new indices and all columns
        # some of the observations get selected multiple times
        exog_boot = exog.loc[boot_sample, :]
        # select the boot sample for outcome
        outcome_boot = outcome.loc[boot_sample]
        # select the boot sample for treatment
        treat_boot = treat.loc[boot_sample]
        # redo ate estimation via ipw passing in the bootstrap sample
        # save the resulting ate estimate under the rep_id in the dictionary
        ate_boot[rep_id], _ = ate_ipw(
            exog=exog_boot, outcome=outcome_boot,
            treat=treat_boot, intercept=intercept,
            lasso=lasso, cval=cval, folds=folds)
    # compute standard error for ate as standard deviation of all ate estimates
    # take the values from the dictionary and convert them to a list first
    # take the standard deviation using the numpy module
    ate_se = np.std(ate_boot)
    # return the result
    return ate_se

# own cross-validation for lasso
def my_cv_lasso(exog, outcome, intercept=True, folds=5):
    """
    Cross-validation for lasso.

    Parameters
    ----------
    exog : TYPE: pd.Series
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    intercept : TYPE: boolean
        DESCRIPTION: should intercept be included? The default is True.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cv. The default is 10.

    Returns
    -------
    result: optimal alpha (lambda) and betas and predictions
    """
    
    exog_mean   = exog.mean()
    exog_std    = exog.std().replace(0, 1)   # replace 0 to avoid dividing by zero
    exog_scaled = (exog - exog_mean) / exog_std
    
    # define grid of alphas to optimize over (the more alphas, the longer comp)
    alpha_grid = np.arange(0.001, 0.01, 0.001)
    # create storage for mse as an empty dictionary
    # to easily fill in values including the corresponding names
    alpha_mse = np.empty_like(alpha_grid)
    # get the equally large folds from 0 to folds-1 (folds in total)
    # draw random integers of equal probabilities in size of the sample
    fold_ids = np.random.randint(0, folds, size=exog.shape[0])
    # start the loop of alphas from the grid
    # the loop goes through each tuning parameter value specified
    for jdx, alpha in enumerate(alpha_grid):
        # create storage for mse as an empty list as we do not need names here
        cv_mse = []
        # start the loop for cross-validation
        # the loop goes through each fold from the unique set of folds
        for fold in np.unique(fold_ids):
            # estimate on all but current fold and test on index fold
            # use linear lasso from the scikit-learn module as it is faster
            # than the one from statsmodels
            model = linear_model.Lasso(alpha=alpha, fit_intercept=intercept
                                       )
            model.fit(X=exog.loc[fold_ids != fold, :],
                      y=outcome.loc[fold_ids != fold])
            # alternatively with statsmodels:
            # model = sm.OLS(endog=outcome.loc[fold_ids != fold],
            #               exog=exog.loc[fold_ids != fold, :]
            # ).fit_regularized(alpha=alpha)
            # predict on the current fold, i.e. the out-of-sample fold
            yhat = model.predict(X=exog.loc[fold_ids == fold, :])
            # compute mse on the current fold by comparing the predictions with
            # actual outcome for the current fold and append the values to list
            cv_mse.append(np.mean((outcome.loc[fold_ids == fold] - yhat) ** 2))
        # now we completed the cross-validation loop
        # take the mean of the cross-validated mse and assign it to the alpha
        alpha_mse[jdx] = np.mean(cv_mse)
    # now we completed the cv mse evaluation for all alphas
    # get the alpha value with smallest mse from the dictionary
    # keys are the alpha values from the grid
    alpha_opt = alpha_grid[np.argmin(alpha_mse)]
    # predict on the whole sample with the optimal alpha
    # use linear lasso from the scikit-learn module as it is faster
    model = linear_model.Lasso(alpha=alpha_opt, fit_intercept=intercept
                               ).fit(X=exog, y=outcome)
    # alternatively with statsmodels:
    # lasso = sm.OLS(endog=outcome, exog=exog).fit_regularized(alpha=alpha_opt)
    # predict the outcome for the whole sample
    yhat = model.predict(X=exog)
    # extract the coefficients from the estimated model (convert to lists)
    # check if intercept should be included
    # the following condition checks implicitly if intercept == True
    if intercept:
        # if True, take the intercept out of the model too
        betas = pd.Series([model.intercept_] + list(model.coef_),
                          index=['intercept'] + list(exog.columns.values))
    else:
        # if False, do not take the intercept as there is none
        betas = pd.Series(list(model.coef_), index=list(exog.columns.values))
    # bind the output in a dictionary and name the values
    result = {"alpha": alpha_opt, "betas": betas, "predictions": yhat}
    # return the results
    return result


# own ipw function
def my_ipw(exog, outcome, treat, intercept=True, display=True,
           boot=100, lasso=False, cval=False, folds=10, balance=False):
    """
    IPW estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: matrix of covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treat : TYPE: pd.Series
        DESCRIPTION: vector of treatments
    intercept : TYPE: boolean, optional
        DESCRIPTION: if intercept should be used.
        The default is True.
    boot : TYPE: integer, optional
        DESCRIPTION: Number of bootstrap replications for inference.
        The default is 100.
    lasso : TYPE: boolean, optional
        DESCRIPTION: if lasso should be used for propensity score.
        The default is False.
    cval : TYPE: boolean, optional
        DESCRIPTION: if cross-validation should be used for lasso.
        The default is False.
    folds : TYPE: integer, optional
        DESCRIPTION: number of folds for cross-validation.
        The default is 10.

    Returns
    -------
    result: ipw estimates with standard errors
    """
    # estimate ate via ipw and pass on the keyword arguments for estimation
    ate, pscores = ate_ipw(
        exog=exog, outcome=outcome, treat=treat, intercept=intercept,
        lasso=lasso, cval=cval, folds=folds)
    # estimate SE for ATE using bootstrapping and pass on keyword arguments
    ate_se = ate_ipw_boot(exog=exog, outcome=outcome, treat=treat,
                          intercept=intercept, reps=boot, lasso=lasso,
                          cval=cval, folds=folds)
    # compute t and p values
    tval = ate / ate_se
    # compute pvalues based on the students t-distribution (requires scipy)
    # sf stands for the survival function (also defined as 1 - cdf)
    pval = stats.t.sf(np.abs(tval), (exog.shape[0] - exog.shape[1])) * 2
    # combine the results as pd.DataFrame and name the corresponding values
    result = pd.DataFrame([ate, ate_se, tval, pval],
                          index=['coef', 'se', 't-value', 'p-value'],
                          columns=[treat.name]).transpose()
    if balance:
        def helper(x_dat):
            return ipw_formula(treat, x_dat, pscores)
        b_result = exog.apply(helper, axis=0)
    # check if the results should be printed to the console
    # the following condition checks implicitly if display == True
    if display:
        # if True, print the results (\n inserts a line break)
        print('IPW Estimation Results:', '-' * 80,
              'Dependent Variable: ' + outcome.name, '-' * 80,
              round(result, 2), '-' * 80, '\n\n', sep='\n')
    # return the result
    if balance:
        return result, b_result
    return result

def balance_check(data, treatment, variables):
    """
    Check covariate balance.

    Parameters
    ----------
    data : TYPE: pd.DataFrame
        DESCRIPTION: data on which balancing checks should be conducted
    treatment : TYPE: string
        DESCRIPTION: name of the binary treatment variable
    variables : TYPE: tuple
        DESCRIPTION: names of the variables for balancing checks

    Returns
    -------
    Returns and Prints the Table of Descriptive Balancing Checks
    """
    # create storage for output as an empty dictionary for easy value fill
    balance = {}
    # loop over variables
    for varname in variables:
        # define according to treatment status by logical vector of True/False
        # set treated and control apart using the location for subsetting
        # using the .loc both labels as well as booleans are allowed
        treated = data.loc[data[treatment] == 1, varname]
        control = data.loc[data[treatment] == 0, varname]
        # compute difference in means between treated and control
        mdiff = treated.mean() - control.mean()
        # compute the corresponding standard deviation of the difference
        # squared root of sum of variance of treated scaled by the number of
        # treated + variance of control scaled by the number of controls
        mdiff_std = (np.sqrt(treated.var() / len(treated)
                     + control.var() / len(control)))
        # compute the t-value for the difference
        mdiff_tval = mdiff / mdiff_std
        # compute pvalues based on the normal distribution (requires scipy)
        # sf stands for the survival function (also defined as 1 - cdf)
        mdiff_pval = stats.norm.sf(abs(mdiff_tval)) * 2  # twosided
        # compute the standardized difference
        sdiff = abs(mdiff / np.sqrt((treated.var() + control.var()) / 2)) * 100
        # combine values
        balance[varname] = [treated.mean(), control.mean(),
                            mdiff, mdiff_std, mdiff_tval, mdiff_pval, sdiff]
    # convert the dictionary to dataframe for a nicer output and name rows
    # pandas dataframe will automatically take the keys as columns if the
    # data input is a dictionary. Transpose for having the stats as columns
    balance = pd.DataFrame(balance,
                           index=["Treated", "Control", "MeanDiff", "Std",
                                  "tVal", "pVal", "StdDiff"]).transpose()
    # print the descriptives (\n inserts a line break)
    print('Balancing Checks:', '-' * 80,
          round(balance, 2), '-' * 80, '\n\n', sep='\n')
    # return results
    return balance