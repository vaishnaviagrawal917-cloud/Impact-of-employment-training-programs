"""
Data Analytics II: PC1 Functions.

University of St. Gallen.

Vaishnavi Agrawal
"""

# import modules
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plot
from scipy import stats
from pathlib import Path

# Set pandas printing option to see all columns of the data
pd.set_option('display.max_columns', 100)
# without breaking the dataframe into several lines
pd.set_option('expand_frame_repr', False)
# justify the headers for pandas dataframes
pd.set_option('display.colheader_justify', 'right')


# Write a function to produce summary stats:
# mean, variance, standard deviation, maximum and minimum,
# the number of missings, unique values and number of observations
def my_summary_stats(data):
    """
    Summary stats: mean, variance, standard deviation, maximum and minimum.

    Parameters
    ----------
    data : TYPE: pd.DataFrame
        DESCRIPTION: dataframe for which descriptives will be computed
    Returns

    -------
    None. Prints descriptive table od the data
    """
    # generate storage for the stats as an empty dictionary
    my_descriptives = {} #Empty dictionary to store the results
    # loop over columns
    for col_id in data.columns: #Looping over the column names
        # fill in the dictionary with descriptive values by assigning the
        # column ids as keys for the dictionary
        my_descriptives[col_id] = [data[col_id].mean(),                  # mean
                                   data[col_id].var(),               # variance
                                   data[col_id].std(),                # st.dev.
                                   data[col_id].max(),                # maximum
                                   data[col_id].min(),                # minimum
                                   sum(data[col_id].isna()),          # missing #Summation of true/false in each row
                                   len(data[col_id].unique()),  # unique values 
                                   data[col_id].shape[0]]      # number of obs.
    # convert the dictionary to dataframe for a nicer output and name rows
    # pandas dataframe will automatically take the keys as columns if the
    # data input is a dictionary. Transpose for having the stats as columns
    my_descriptives = pd.DataFrame(my_descriptives,
                                   index=['mean', 'var', 'std', 'max', 'min',
                                          'na', 'unique', 'obs']).transpose()
    # define na, unique and obs as integers such that no decimals get printed
    ints = ['na', 'unique', 'obs']  
    # use the .astype() method of pandas dataframes to change the type
    my_descriptives[ints] = my_descriptives[ints].astype(int)
    # print the descriptives, (\n inserts a line break)
    print('Descriptive Statistics:', '-' * 80,
          round(my_descriptives, 2), '-' * 80, '\n\n', sep='\n')
    return my_descriptives

# own procedure to do histograms
def my_hist(data, varname, path, nbins=10, state_name='', year=" "):
    """
    Plot histograms.

    Parameters
    ----------
    data : TYPE: pd.DataFrame
        DESCRIPTION: dataframe containing variables of interest
    varname : TYPE: string
        DESCRIPTION: variable name for which histogram should be plotted
    path : TYPE: string
        DESCRIPTION: path where the plot will be saved
    nbins : TYPE: integer
        DESCRIPTION. Number of bins. The default is 10.

    Returns
    -------
    None. Prints and saves histogram.
    """
    # produce nice histograms
    data[varname].plot.hist(grid=True, bins=nbins, rwidth=0.9, color='grey')
    # add labels
    plot.title('Histogram of ' + varname + ' — ' + str(state_name) + ' ' + str(year))
    plot.xlabel(varname)
    plot.ylabel('Counts')
    plot.grid(axis='y', alpha=0.75)
    # save the plot
    plot.savefig(str(Path(path) / ('histogram_of_' + varname + '_' + str(state_name) + '_' + str(year) + '.png')), bbox_inches='tight', dpi=150)
    # print the plot
    plot.show()
    plot.clf()
    
# own procedure for a balance check
def balance_check(data, treatment, variables):
    """
    Check covariate balance.

    Parameters
    ----------
    data : TYPE: pd.DataFrame
        DESCRIPTION: data on which balancing checks should be conducted
    treatment : TYPE: string
        DESCRIPTION: name of the binary treatment variable
    variables : TYPE: tuple
        DESCRIPTION: names of the variables for balancing checks

    Returns
    -------
    Returns and Prints the Table of Descriptive Balancing Checks
    """
    # create storage for output as an empty dictionary for easy value fill
    balance = {}
    # loop over variables
    for varname in variables:
        # define according to treatment status by logical vector of True/False
        # set treated and control apart using the location for subsetting
        # using the .loc both labels as well as booleans are allowed
        treated = data.loc[data[treatment] == 1, varname]
        control = data.loc[data[treatment] == 0, varname]
        # compute difference in means between treated and control
        mdiff = treated.mean() - control.mean()
        # compute the corresponding standard deviation of the difference
        # squared root of sum of variance of treated scaled by the number of
        # treated + variance of control scaled by the number of controls
        mdiff_std = (np.sqrt(treated.var() / len(treated)
                     + control.var() / len(control)))
        # compute the t-value for the difference
        mdiff_tval = mdiff / mdiff_std
        # compute pvalues based on the normal distribution (requires scipy)
        # sf stands for the survival function (also defined as 1 - cdf)
        mdiff_pval = stats.norm.sf(abs(mdiff_tval)) * 2  # twosided
        # compute the standardized difference
        sdiff = abs(mdiff / np.sqrt((treated.var() + control.var()) / 2)) * 100
        # combine values
        balance[varname] = [treated.mean(), control.mean(),
                            mdiff, mdiff_std, mdiff_tval, mdiff_pval, sdiff]
    # convert the dictionary to dataframe for a nicer output and name rows
    # pandas dataframe will automatically take the keys as columns if the
    # data input is a dictionary. Transpose for having the stats as columns
    balance = pd.DataFrame(balance,
                           index=["Treated", "Control", "MeanDiff", "Std",
                                  "tVal", "pVal", "StdDiff"]).transpose()
    # print the descriptives (\n inserts a line break)
    print('Balancing Checks:', '-' * 80,
          round(balance, 2), '-' * 80, '\n\n', sep='\n')
    # return results
    return balance


# ATE estimation by mean differences
def ate_md(outcome, treatment):
    """
    Estimate ATE by differences in means.

    Parameters
    ----------
    outcome : TYPE: pd.Series
        DESCRIPTION: vector of outcomes
    treatment : TYPE: pd.Series
        DESCRIPTION: vector of treatments

    Returns
    -------
    results : ATE with Standard Error
    """
    # outcomes y according to treatment status by logical vector of True/False
    # set treated and control apart using the location for subsetting
    # using the .loc both labels as well as booleans are allowed
    y_1 = outcome.loc[treatment == 1]
    y_0 = outcome.loc[treatment == 0]
    # compute ATE and its standard error and t-value
    ate = y_1.mean() - y_0.mean()
    ate_se = np.sqrt(y_1.var() / len(y_1) + y_0.var() / len(y_0))
    ate_tval = ate / ate_se
    # compute pvalues based on the normal distribution (requires scipy)
    # sf stands for the survival function (also defined as 1 - cdf)
    ate_pval = stats.norm.sf(abs(ate_tval)) * 2  # twosided
    # alternatively ttest_ind() could be used directly
    # stats.ttest_ind(a=y_1, b=y_0, equal_var=False)
    # convert the dictionary to dataframe for a nicer output and name rows
    # pandas dataframe will automatically take the keys as columns if the
    # data input is a dictionary. Transpose for having the stats as columns
    result = pd.DataFrame([ate, ate_se, ate_tval, ate_pval],
                          index=['ATE', 'SE', 't-value', 'p-value'],
                          columns=['MeanDiff']).transpose()
    # return and print result (\n inserts a line break)
    print('ATE Estimate by Difference in Means:', '-' * 80,
          'Dependent Variable: ' + outcome.name, '-' * 80,
          round(result, 2), '-' * 80, '\n\n', sep='\n')
    # return the resulting dataframe too
    return result


# use own ols procedure
def my_ols(exog, outcome, intercept=True, display=True):
    """
    OLS estimation.

    Parameters
    ----------
    exog : TYPE: pd.DataFrame
        DESCRIPTION: covariates
    outcome : TYPE: pd.Series
        DESCRIPTION: outcome
    intercept : TYPE: boolean
        DESCRIPTION: should intercept be included? The default is True.
    display : TYPE: boolean
        DESCRIPTION: should results be displayed? The default is True.

    Returns
    -------
    result: ols estimates with standard errors
    """
    # check if intercept should be included
    # the following condition checks implicitly if intercept == True
    if intercept:
        # if True, prepend a vector of ones to the covariate matrix
        exog = pd.concat([pd.Series(np.ones(len(exog)), index=exog.index,
                                    name='intercept'), exog], axis=1)
    # compute (x'x)-1 by using the linear algebra from numpy

    x_inv = np.linalg.inv(np.dot(exog.T, exog))
    # estimate betas according to the OLS formula b=(x'x)^(-1)(x'y)
    betas = np.dot(x_inv, np.dot(exog.T, outcome))
    # compute the residuals by subtracting fitted values from the outcomes
    res = outcome - np.dot(exog, betas)
    # estimate standard errors for the beta coefficients
    # se = square root of diag((u'u)(x'x)^(-1)/(N-p))
    s_e = np.sqrt(np.diagonal(np.dot(np.dot(res.T, res), x_inv) /
                              (exog.shape[0] - exog.shape[1])))
    # compute the t-values
    tval = betas / s_e
    # compute pvalues based on the students t-distribution (requires scipy)
    # sf stands for the survival function (also defined as 1 - cdf)
    # degrees of freedom as N - p using the shape method of pandas
    pval = stats.t.sf(np.abs(tval),
                      (exog.shape[0] - exog.shape[1])) * 2
    # put results into dataframe and name the corresponding values
    result = pd.DataFrame([betas, s_e, tval, pval],
                          index=['coef', 'se', 't-value', 'p-value'],
                          columns=list(exog.columns.values)).transpose()
    # check if the results should be printed to the console
    # the following condition checks implicitly if display == True
    if display:
        # if True, print the results (\n inserts a line break)
        print('OLS Estimation Results:', '-' * 80,
              'Dependent Variable: ' + outcome.name, '-' * 80,
              round(result, 2), '-' * 80, '\n\n', sep='\n')
    # return the resulting dataframe too
    return result


# multiple testing
def multiple_testing(level, subgroups):
    """
    Check multiple testing.

    Parameters
    ----------
    level : TYPE: float
        DESCRIPTION: significance level
    subgroups : TYPE: integer
        DESCRIPTION: number of subgroups for heterogeneity

    Returns
    -------
    result: probability of finding at least one significant effect

    """
    # compute the probability according to the formula
    prob = 1 - (1 - level) ** subgroups
    # print the result
    print(f'''Probability of at least one significant effect at {level} level
          with {subgroups} subgroups is: {round(prob, 4)}.\n''')
    # return the result
    return prob


# own procedure for testing the differences
def test_diff(means, serrors):
    """
    Test for differences in means.

    Parameters
    ----------
    means : TYPE: tuple
        DESCRIPTION: means of sample 1 and sample 2
    serrors : TYPE: tuple
        DESCRIPTION: standard errors of sample 1 and sample 2

    Returns
    -------
    result: mean, se, t-value and p-value for test if difference is zero.
    """
    # get the difference of the means
    mean_diff = means[0] - means[1]
    # get standard error for the difference
    se_diff = np.sqrt(serrors[0] ** 2 + serrors[1] ** 2)
    # get t-value
    t_val = mean_diff / se_diff
    # compute pvalues based on the normal distribution (requires scipy)
    p_val = stats.norm.sf(abs(t_val)) * 2  # twosided
    # bind result into dataframe
    result = pd.DataFrame([mean_diff, se_diff, t_val, p_val],
                          index=['coef', 'se', "t-value", "p-value"],
                          columns=['Diff in Means']).transpose()
    # print the result (\n inserts a line break)
    print('Results for Test if Difference in Means is Zero:', '-' * 80,
          round(result, 2), '-' * 80, '\n\n', sep='\n')
    # return the result
    return result


# define an Output class for simultaneous console - file output
class Output():
    """Output class for simultaneous console/file output."""

    def __init__(self, path, name):

        self.terminal = sys.stdout
#        self.output = open(path + '/' + name + ".txt", "w", encoding='utf-8')
        self.output = open(path / (name + ".txt"), "w", encoding='utf-8')

    def write(self, message):
        """Write both into terminal and file."""
        self.terminal.write(message)
        self.output.write(message)

    def flush(self):
        """Python 3 compatibility."""
